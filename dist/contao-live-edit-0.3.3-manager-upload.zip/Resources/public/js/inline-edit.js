(() => {
  const fields = '[data-inline-record][data-inline-field]';
  const basePath = (document.querySelector('meta[name="contao-live-edit-base-path"]')?.content || '').replace(/\/$/, '');
  const appUrl = (path) => `${basePath}${path.startsWith('/') ? path : `/${path}`}`;
  const token = document.querySelector('meta[name="contao-live-edit-inline-token"]')?.content;
  if (!token) return;
  const activationKey = 'contao-live-edit-editor-active';

  const revealContaoHiddenElements = (root = document) => {
    const elements = [];
    if (root.nodeType === Node.ELEMENT_NODE && root.matches('[data-contao-live-edit-invisible="true"]')) elements.push(root);
    elements.push(...root.querySelectorAll('[data-contao-live-edit-invisible="true"]'));
    for (const element of elements) {
      const parent = element.parentElement;
      if (parent && !parent.matches('[data-contao-live-edit-invisible="true"]')) {
        const parentStyle = getComputedStyle(parent);
        if (parentStyle.display === 'none' || parentStyle.visibility === 'hidden') continue;
      }
      const style = getComputedStyle(element);
      const display = style.display === 'none' ? ({
        LI: 'list-item', TR: 'table-row', TD: 'table-cell', TH: 'table-cell',
        THEAD: 'table-header-group', TBODY: 'table-row-group', TFOOT: 'table-footer-group',
        SPAN: 'inline', A: 'inline', EM: 'inline', STRONG: 'inline', SMALL: 'inline',
        LABEL: 'inline', CODE: 'inline', TIME: 'inline', IMG: 'inline-block',
      }[element.tagName] || 'block') : style.display;
      const width = Number.parseFloat(style.width) || 0;
      const height = Number.parseFloat(style.height) || 0;
      const hasClip = style.clip !== 'auto' || style.clipPath !== 'none';
      const visuallyClipped = hasClip || (width <= 1 && height <= 1 && (style.overflow !== 'visible' || style.position === 'absolute' || style.position === 'fixed'));
      element.style.setProperty('--contao-live-edit-reveal-display', display);
      element.dataset.contaoLiveEditRevealClipped = String(visuallyClipped);
      element.classList.add('contao-live-edit-preview-hidden');
      element.removeAttribute('data-contao-live-edit-hidden-label');
    }
  };

  revealContaoHiddenElements();
  new MutationObserver((changes) => {
    for (const { addedNodes } of changes) {
      for (const node of addedNodes) if (node.nodeType === Node.ELEMENT_NODE) revealContaoHiddenElements(node);
    }
  }).observe(document.documentElement, { childList: true, subtree: true });

  let activeField = null;
  let originalMarkup = '';
  let beginSequence = 0;
  let textMode = false;
  let popover = null;
  let popoverOpener = null;
  let templateOpener = null;
  let popoverDirty = false;
  let pendingClick = null;
  let replayingClick = false;
  let imagePreviewUrl = null;
  textMode = sessionStorage.getItem(activationKey) === 'true';

  const markNewsFields = () => {
    for (const article of document.querySelectorAll('.contao-live-edit-news')) {
      const idClass = [...article.classList].find((name) => /^contao-live-edit-news-\d+$/.test(name));
      const id = idClass?.slice('contao-live-edit-news-'.length);
      if (!id) continue;
      const mark = (element, name, wrapLink = false) => {
        if (!element) return;
        let field = element;
        if (wrapLink && element.matches('a')) {
          field = element.querySelector(':scope > .contao-live-edit-news-inline-field');
          if (!field) {
            field = document.createElement('span');
            field.className = 'contao-live-edit-news-inline-field';
            while (element.firstChild) field.append(element.firstChild);
            element.append(field);
          }
        }
        field.dataset.inlineRecord = id;
        field.dataset.inlineRecordType = 'news';
        field.dataset.inlineField = name;
      };
      const headline = article.querySelector('.project-caption h2')
        || article.querySelector(':scope > h1')
        || article.querySelector('.case-header h1')
        || article.querySelector(':scope > h2');
      const headlineFields = new Set([headline, ...article.querySelectorAll('.project-empty .empty-title')].filter(Boolean));
      for (const title of headlineFields) {
        const editableTitle = title.matches('a') ? title : (title.querySelector(':scope > a') || title);
        mark(editableTitle, 'headline', true);
      }
      const subheadline = article.querySelector('.case-header h1')
        ? article.querySelector('.case-header .case-lede')
        : article.querySelector(':scope > h1') ? article.querySelector(':scope > h2') : null;
      if (subheadline) mark(subheadline, 'subheadline');
      const teaserFields = new Set(article.querySelectorAll(':scope > .content-text, .project-overlay-copy, .project-teaser, .case-fallback .case-copy'));
      for (const teaser of teaserFields) mark(teaser, 'teaser');
    }
  };

  markNewsFields();
  new MutationObserver((changes) => {
    if (changes.some(({ addedNodes }) => [...addedNodes].some((node) => node.nodeType === Node.ELEMENT_NODE && (node.matches('.contao-live-edit-news') || node.querySelector('.contao-live-edit-news'))))) markNewsFields();
  }).observe(document.body, { childList: true, subtree: true });

  const bar = document.createElement('div');
  bar.className = 'contao-live-edit-inline-bar is-ready';
  bar.setAttribute('role', 'region');
  bar.setAttribute('aria-label', 'Live editing controls');
  bar.innerHTML = '<span class="contao-live-edit-inline-hint">Select text to edit · Hover over a block for its controls</span><span class="contao-live-edit-inline-status" aria-live="polite"></span><div class="contao-live-edit-inline-actions"><button type="button" data-context-toggle aria-expanded="false" aria-controls="contao-live-edit-context-drawer" aria-label="Open page tools" title="Page tools"><svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="4" cy="10" r="1.5"/><circle cx="10" cy="10" r="1.5"/><circle cx="16" cy="10" r="1.5"/></svg></button><button type="button" data-action="toggle" aria-label="Start live editing" title="Start live editing"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m21.64 3.64-1.28-1.28a1.21 1.21 0 0 0-1.72 0L2.36 18.64a1.21 1.21 0 0 0 0 1.72l1.28 1.28a1.2 1.2 0 0 0 1.72 0L21.64 5.36a1.2 1.2 0 0 0 0-1.72"/><path d="m14 7 3 3"/><path d="M5 6v4"/><path d="M19 14v4"/><path d="M10 2v2"/><path d="M7 8H3"/><path d="M21 16h-4"/><path d="M11 3H9"/></svg><span data-live-edit-label>Start live editing</span></button></div><button type="button" data-action="cancel">Cancel</button><button type="button" data-action="save">Save</button><nav class="contao-live-edit-context-drawer" id="contao-live-edit-context-drawer" aria-label="Page tools" hidden><button type="button" data-context-template>Template studio</button><a data-context-page>Page settings</a><div class="contao-live-edit-context-articles"><button type="button" data-context-articles-toggle aria-expanded="false" aria-controls="contao-live-edit-context-article-list"><span>Articles</span><span aria-hidden="true">›</span></button><div class="contao-live-edit-context-article-popout" id="contao-live-edit-context-article-list" data-context-article-list></div></div><div class="contao-live-edit-context-divider" role="separator"></div><a data-context-route="modules">Modules</a><a data-context-route="image-sizes">Image sizes</a><a data-context-route="layouts">Layouts</a></nav>';
  document.body.append(bar);

  const status = bar.querySelector('.contao-live-edit-inline-status');
  const toggleButton = bar.querySelector('[data-action="toggle"]');
  const toggleLabel = toggleButton.querySelector('[data-live-edit-label]');
  const saveButton = bar.querySelector('[data-action="save"]');
  const cancelButton = bar.querySelector('[data-action="cancel"]');
  const contextToggle = bar.querySelector('[data-context-toggle]');
  const contextDrawer = bar.querySelector('.contao-live-edit-context-drawer');
  const articleList = contextDrawer.querySelector('[data-context-article-list]');
  const articlesGroup = contextDrawer.querySelector('.contao-live-edit-context-articles');
  const articlesToggle = contextDrawer.querySelector('[data-context-articles-toggle]');
  document.body.append(contextDrawer);
  let backendPopover = null;
  let backendPopoverOpener = null;

  const buildContextMenu = () => {
    const pageLink = contextDrawer.querySelector('[data-context-page]');
    const pageSettingsUrl = document.querySelector('meta[name="contao-live-edit-page-settings-url"]')?.content;
    const pageName = document.querySelector('meta[name="contao-live-edit-page-name"]')?.content?.trim();
    pageLink.hidden = !pageSettingsUrl;
    if (pageSettingsUrl) {
      pageLink.href = pageSettingsUrl;
      pageLink.textContent = pageName ? `Page settings · ${pageName}` : 'Page settings';
    }

    const destinations = {
      modules: 'modules',
      'image-sizes': 'image-sizes',
      layouts: 'layouts',
    };
    for (const link of contextDrawer.querySelectorAll('[data-context-route]')) {
      const name = destinations[link.dataset.contextRoute];
      const url = document.querySelector(`meta[name="contao-live-edit-${name}-url"]`)?.content;
      link.hidden = !url;
      if (url) link.href = url;
    }

    prepareArticles();
    const articles = new Map();
    for (const article of document.querySelectorAll('.contao-live-edit-article')) {
      const match = [...article.classList].map((name) => name.match(/^contao-live-edit-article-(\d+)$/)).find(Boolean);
      const id = match?.[1];
      const href = article.dataset.contaoLiveEditArticleUrl;
      if (!id || !href || articles.has(id)) continue;
      const title = article.querySelector('h1,h2,h3,[data-contao-live-edit-article-title]')?.textContent?.trim().replace(/\s+/g, ' ');
      articles.set(id, { href, title: title || `Article ${id}` });
    }
    articleList.replaceChildren();
    if (!articles.size) {
      const empty = document.createElement('p');
      empty.className = 'contao-live-edit-context-empty';
      empty.textContent = 'No articles found on this page.';
      articleList.append(empty);
      return;
    }
    for (const article of articles.values()) {
      const link = document.createElement('a');
      link.href = article.href;
      link.textContent = article.title;
      articleList.append(link);
    }
  };
  const setArticlesOpen = (open) => {
    articlesGroup.classList.toggle('is-open', open);
    articlesToggle.setAttribute('aria-expanded', String(open));
    if (open) positionArticlesPopout();
  };
  let articlesCloseTimer = null;
  const keepArticlesOpen = () => {
    window.clearTimeout(articlesCloseTimer);
    setArticlesOpen(true);
  };
  const deferArticlesClose = () => {
    window.clearTimeout(articlesCloseTimer);
    articlesCloseTimer = window.setTimeout(() => setArticlesOpen(false), 180);
  };
  articlesGroup.addEventListener('pointerenter', (event) => {
    if (event.pointerType === 'mouse' || event.pointerType === 'pen') keepArticlesOpen();
  });
  articlesGroup.addEventListener('pointerleave', (event) => {
    if (event.pointerType === 'mouse' || event.pointerType === 'pen') deferArticlesClose();
  });
  const articlePopout = articlesGroup.querySelector('.contao-live-edit-context-article-popout');
  articlePopout.addEventListener('pointerenter', keepArticlesOpen);
  articlePopout.addEventListener('pointerleave', deferArticlesClose);
  articlesGroup.addEventListener('focusin', () => setArticlesOpen(true));
  articlesGroup.addEventListener('focusout', (event) => {
    if (!articlesGroup.contains(event.relatedTarget)) setArticlesOpen(false);
  });
  articlesToggle.addEventListener('click', () => setArticlesOpen(articlesToggle.getAttribute('aria-expanded') !== 'true'));
  const closeBackendPopover = () => {
    if (!backendPopover || backendPopover.hidden) return;
    backendPopover.hidden = true;
    const opener = backendPopoverOpener;
    backendPopoverOpener = null;
    backendPopover.querySelector('iframe').src = 'about:blank';
    if (opener?.isConnected) opener.focus();
  };
  const openBackendPopover = (url, title, opener) => {
    if (!backendPopover) {
      backendPopover = document.createElement('section');
      backendPopover.className = 'contao-live-edit-backend-popover';
      backendPopover.setAttribute('role', 'dialog');
      backendPopover.setAttribute('aria-modal', 'false');
      backendPopover.setAttribute('aria-labelledby', 'contao-live-edit-backend-popover-title');
      backendPopover.hidden = true;
      backendPopover.innerHTML = '<header><h2 id="contao-live-edit-backend-popover-title"></h2><button type="button" data-backend-popover-close aria-label="Close">×</button></header><iframe title="Contao settings" loading="eager" referrerpolicy="same-origin"></iframe>';
      document.body.append(backendPopover);
      backendPopover.querySelector('[data-backend-popover-close]').addEventListener('click', closeBackendPopover);
    }
    backendPopoverOpener = opener;
    backendPopover.querySelector('h2').textContent = title;
    backendPopover.querySelector('iframe').src = url;
    backendPopover.hidden = false;
    backendPopover.querySelector('[data-backend-popover-close]').focus();
  };
  contextDrawer.addEventListener('click', (event) => {
    const link = event.target.closest('a[href]');
    if (!link) return;
    const target = new URL(link.href, window.location.href);
    if (target.origin !== window.location.origin) return;
    event.preventDefault();
    setContextMenuOpen(false);
    setArticlesOpen(false);
    openBackendPopover(target.href, link.textContent.trim(), link);
  });
  const positionContextDrawer = () => {
    if (contextDrawer.hidden) return;
    const viewport = window.visualViewport;
    const viewportLeft = viewport?.offsetLeft || 0;
    const viewportTop = viewport?.offsetTop || 0;
    const viewportWidth = viewport?.width || window.innerWidth;
    const viewportHeight = viewport?.height || window.innerHeight;
    const margin = 12;
    const width = Math.min(340, Math.max(0, viewportWidth - margin * 2));
    const availableHeight = Math.max(120, viewportHeight - margin * 2);
    contextDrawer.style.position = 'fixed';
    contextDrawer.style.width = `${width}px`;
    contextDrawer.style.maxHeight = `${availableHeight}px`;
    contextDrawer.style.right = 'auto';
    contextDrawer.style.bottom = 'auto';
    const anchor = contextToggle.getBoundingClientRect();
    const height = contextDrawer.getBoundingClientRect().height;
    const left = Math.max(viewportLeft + margin, Math.min(anchor.right - width, viewportLeft + viewportWidth - width - margin));
    let top = anchor.top - height - margin;
    if (top < viewportTop + margin) top = anchor.bottom + margin;
    top = Math.max(viewportTop + margin, Math.min(top, viewportTop + viewportHeight - height - margin));
    contextDrawer.style.left = `${left}px`;
    contextDrawer.style.top = `${top}px`;
  };
  const positionArticlesPopout = () => {
    const popout = articlesGroup.querySelector('.contao-live-edit-context-article-popout');
    if (!popout || contextDrawer.hidden) return;
    const viewport = window.visualViewport;
    const viewportLeft = viewport?.offsetLeft || 0;
    const viewportTop = viewport?.offsetTop || 0;
    const viewportWidth = viewport?.width || window.innerWidth;
    const viewportHeight = viewport?.height || window.innerHeight;
    const drawerRect = contextDrawer.getBoundingClientRect();
    const groupRect = articlesGroup.getBoundingClientRect();
    const gap = 12;
    const margin = 12;
    const leftSpace = Math.max(0, drawerRect.left - viewportLeft - gap - margin);
    const rightSpace = Math.max(0, viewportLeft + viewportWidth - drawerRect.right - gap - margin);
    const sideSpace = Math.max(leftSpace, rightSpace);
    popout.style.left = 'auto';
    popout.style.right = 'auto';
    popout.style.top = '0px';
    if (sideSpace >= 140) {
      popout.style.position = 'absolute';
      popout.style.width = `${Math.min(300, sideSpace)}px`;
      if (leftSpace >= rightSpace) popout.style.right = `calc(100% + ${gap}px)`;
      else popout.style.left = `calc(100% + ${gap}px)`;
      const height = popout.getBoundingClientRect().height;
      const top = Math.max(viewportTop + margin, Math.min(groupRect.top, viewportTop + viewportHeight - height - margin));
      popout.style.top = `${top - groupRect.top}px`;
      return;
    }
    // On narrow screens, put the list directly below Articles rather than
    // letting a side panel cover the row or spill beyond the viewport.
    popout.style.position = 'static';
    popout.style.width = '100%';
    popout.style.maxHeight = `${Math.max(120, Math.min(viewportHeight * 0.45, 360))}px`;
  };
  const setContextMenuOpen = (open) => {
    contextDrawer.hidden = !open;
    contextToggle.setAttribute('aria-expanded', String(open));
    if (open) {
      buildContextMenu();
      positionContextDrawer();
    }
  };
  const repositionContextMenus = () => {
    positionContextDrawer();
    if (articlesGroup.classList.contains('is-open')) positionArticlesPopout();
  };
  window.addEventListener('resize', repositionContextMenus, { passive: true });
  window.visualViewport?.addEventListener('resize', repositionContextMenus, { passive: true });
  window.visualViewport?.addEventListener('scroll', repositionContextMenus, { passive: true });
  contextToggle.addEventListener('click', () => setContextMenuOpen(contextDrawer.hidden));
  contextDrawer.querySelector('[data-context-template]').addEventListener('click', () => {
    setContextMenuOpen(false);
    openTemplateEditor(document.documentElement.dataset.contaoLiveEditPageTemplate || '', 'page');
  });
  document.addEventListener('pointerdown', (event) => {
    if (!contextDrawer.hidden && !contextDrawer.contains(event.target) && !contextToggle.contains(event.target)) setContextMenuOpen(false);
    if (backendPopover && !backendPopover.hidden && !event.target.closest('.contao-live-edit-backend-popover')) closeBackendPopover();
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && backendPopover && !backendPopover.hidden) {
      closeBackendPopover();
      return;
    }
    if (event.key === 'Escape' && !contextDrawer.hidden) {
      setContextMenuOpen(false);
      contextToggle.focus();
    }
  });

  const isActive = () => textMode;
  const setMessage = (message, error = false) => {
    status.textContent = message;
    status.classList.toggle('is-error', error);
  };

  const finish = (restore, discardConfirmed = false) => {
    if (!activeField) return true;
    if (restore && !discardConfirmed && activeField.innerHTML !== originalMarkup && !window.confirm('Discard your unsaved text changes?')) return false;
    if (restore) activeField.innerHTML = originalMarkup;
    activeField.contentEditable = 'false';
    activeField.classList.remove('is-inline-editing');
    renderedStateByField.delete(activeField);
    activeField = null;
    bar.classList.remove('is-editing');
    saveButton.disabled = false;
    setMessage('');
    return true;
  };

  const syncActivation = () => {
    if (!isActive() && popover && !closePopover()) textMode = true;
    if (!isActive() && activeField && !finish(true)) textMode = true;
    const active = isActive();
    if (!active) beginSequence += 1;
    sessionStorage.setItem(activationKey, String(active));
    bar.classList.toggle('is-active', active);
    document.body.classList.toggle('contao-live-edit-text-editing', active);
    toggleLabel.textContent = active ? 'Live editing on' : 'Start live editing';
    toggleButton.setAttribute('aria-pressed', String(active));
    toggleButton.setAttribute('aria-label', active ? 'Stop live editing' : 'Start live editing');
    toggleButton.title = active ? 'Stop live editing' : 'Start live editing';
    updateKeyboardTargets(active);
  };
  new MutationObserver(syncActivation).observe(document.body, { attributes: true, attributeFilter: ['class'] });

  const renderedStateByField = new WeakMap();
  const mergeRenderedState = (field, markup) => {
    const template = document.createElement('template');
    template.innerHTML = markup;

    const liveElements = [field, ...field.querySelectorAll('*')];
    const paths = new Map();
    const pathFor = (element, root) => {
      const path = [];
      for (let node = element; node && node !== root; node = node.parentElement || node.parentNode) {
        const parent = node.parentElement || node.parentNode;
        if (!parent) return null;
        path.unshift([...parent.children].indexOf(node));
      }
      return path;
    };
    liveElements.forEach((element) => {
      const path = pathFor(element, field);
      if (path) paths.set(path.join('.'), element);
    });

    const renderedState = [];
    const sourceElements = [...template.content.querySelectorAll('*')];
    sourceElements.forEach((element) => {
      const path = pathFor(element, template.content);
      const live = (element.id ? field.querySelector(`#${CSS.escape(element.id)}`) : null)
        || paths.get(path?.join('.'));
      if (!live || live.tagName !== element.tagName) return;

      const addedClasses = [];
      live.classList.forEach((className) => {
        if (!element.classList.contains(className)) {
          element.classList.add(className);
          addedClasses.push(className);
        }
      });
      const addedStyles = [];
      for (const property of live.style) {
        if (!element.style.hasProperty(property)) {
          element.style.setProperty(property, live.style.getPropertyValue(property), live.style.getPropertyPriority(property));
          addedStyles.push(property);
        }
      }
      if (addedClasses.length || addedStyles.length) renderedState.push({ id: element.id, path, addedClasses, addedStyles });
    });

    const editorControls = [...field.children].filter((child) => child.matches('.contao-live-edit-action-bar, .contao-live-edit-move-handle, .contao-live-edit-settings-handle'));
    for (const child of [...field.childNodes]) {
      if (!editorControls.includes(child)) child.remove();
    }
    field.insertBefore(template.content.cloneNode(true), editorControls[0] || null);
    renderedStateByField.set(field, renderedState);
  };

  const begin = async (field, selectAll = true) => {
    if (!isActive()) return;
    if (activeField === field) return;
    if (activeField && activeField !== field && !finish(true)) return;
    const sequence = ++beginSequence;
    let sourceValue;
    if (field.dataset.inlineRecord && field.dataset.inlineField) {
      try {
        const source = await request('/contao-live-edit/inline-source', {
          id: field.dataset.inlineRecord,
          recordType: field.dataset.inlineRecordType || 'content',
          field: field.dataset.inlineField,
        });
        if (sequence !== beginSequence || !isActive()) return;
        sourceValue = source.value;
      } catch (error) {
        if (sequence !== beginSequence) return;
        setMessage(error.message || 'Could not load the saved text.', true);
        return;
      }
    }
    if (sequence !== beginSequence || !isActive()) return;
    activeField = field;
    originalMarkup = field.innerHTML;
    if (undefined !== sourceValue) {
      if (['text', 'teaser'].includes(field.dataset.inlineField)) mergeRenderedState(field, sourceValue);
      else field.textContent = sourceValue;
    }
    field.contentEditable = 'true';
    field.classList.add('is-inline-editing');
    bar.classList.add('is-editing');
    setMessage('');
    field.focus();
    if (selectAll) {
      const selection = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(field);
      selection.removeAllRanges();
      selection.addRange(range);
    }
  };

  const closePopover = (discardConfirmed = false) => {
    if (!popover) return true;
    if (popover.dataset.saving === 'true') return false;
    if (popoverDirty && !discardConfirmed && !window.confirm('Discard your unsaved changes?')) return false;
    popover?.querySelectorAll('textarea.contao-live-edit-native-rte').forEach((textarea) => window.hugerte?.get(textarea.id)?.remove());
    popover?.remove();
    popover = null;
    popoverDirty = false;
    const opener = popoverOpener;
    popoverOpener = null;
    if (opener?.isConnected) opener.focus();
    if (imagePreviewUrl) URL.revokeObjectURL(imagePreviewUrl);
    imagePreviewUrl = null;
    return true;
  };
  const trackPopoverChanges = () => {
    popoverDirty = false;
    const currentPopover = popover;
    currentPopover?.addEventListener('input', () => { popoverDirty = true; });
    currentPopover?.addEventListener('change', () => { popoverDirty = true; });
  };
  const setPopoverSaving = (saving) => {
    if (!popover) return;
    popover.dataset.saving = String(saving);
    for (const control of popover.querySelectorAll('button,input,textarea,select')) {
      if (saving) {
        control.dataset.preSavingDisabled = String(control.disabled);
        control.disabled = true;
      } else {
        control.disabled = control.dataset.preSavingDisabled === 'true';
        delete control.dataset.preSavingDisabled;
      }
    }
  };

  let templateModal;
  let templateAce;
  let templateAcePromise;
  let templateAceAssetsLoaded = false;
  let templateSelectedPath = '';
  let templateOriginalSource = '';
  const templateHasUnsavedChanges = () => Boolean(templateSelectedPath)
    && (templateAce ? templateAce.getValue() : templateModal?.querySelector('[data-template-source]')?.value || '') !== templateOriginalSource;
  const closeTemplateModal = () => {
    if (templateHasUnsavedChanges() && !window.confirm('Discard unsaved template changes?')) return;
    templateModal?.remove();
    const opener = templateOpener;
    templateOpener = null;
    if (opener?.isConnected) opener.focus();
  };
  const loadTemplateAce = async () => {
    if (templateAceAssetsLoaded) return;
    if (!window.ace) {
      templateAcePromise ||= new Promise((resolve, reject) => {
        const script = document.createElement('script'); script.src = appUrl('/assets/ace/js/ace.js'); script.onload = resolve; script.onerror = () => reject(new Error('Code highlighting is unavailable.'));
        document.head.append(script);
      });
      await templateAcePromise;
    }
    const loadMode = (file) => new Promise((resolve, reject) => {
      const script = document.createElement('script'); script.src = appUrl(`/assets/ace/js/${file}`); script.onload = resolve; script.onerror = () => reject(new Error('Code highlighting is unavailable.'));
      document.head.append(script);
    });
    await Promise.all([loadMode('mode-html.js'), loadMode('mode-twig.js'), loadMode('theme-chrome.js'), loadMode('theme-dracula.js')]);
    templateAceAssetsLoaded = true;
  };
  const openTemplateEditor = async (preferredPath = '', recordType = '') => {
    const opener = document.activeElement;
    if (activeField && !finish(true)) return;
    if (!closePopover()) return;
    templateOpener = opener;
    if (!templateModal) {
      templateModal = document.createElement('div');
      templateModal.className = 'contao-live-edit-template-modal';
      templateModal.innerHTML = '<section class="contao-live-edit-template-card" role="dialog" aria-modal="true" aria-labelledby="contao-live-edit-template-title" tabindex="-1"><header><div><span class="contao-live-edit-modal-kicker">PROJECT TEMPLATES</span><h2 id="contao-live-edit-template-title">Edit a Contao template</h2><p>Changes are written to the selected file in the project templates folder. Each save keeps a previous version you can restore.</p></div><button type="button" data-template-close aria-label="Close">×</button></header><div class="contao-live-edit-template-layout"><aside><label class="contao-live-edit-template-search">Find a template<input type="search" placeholder="Search templates"></label><nav data-template-list aria-label="Project templates"><p class="contao-live-edit-library-message">Loading templates…</p></nav></aside><main><div class="contao-live-edit-template-file" data-template-path>Select a template to begin</div><div class="contao-live-edit-template-ace" data-template-ace hidden></div><textarea data-template-source spellcheck="false" aria-label="Template source" disabled></textarea></main></div><footer><span data-template-status aria-live="polite">Choose a template from the list.</span><button type="button" data-template-restore disabled>Restore previous version</button><button type="button" data-template-close>Close</button><button type="button" data-template-save disabled>Save template</button></footer></section>';
      document.body.append(templateModal);
      templateModal.querySelectorAll('[data-template-close]').forEach((button) => button.addEventListener('click', closeTemplateModal));
      templateModal.addEventListener('click', (event) => { if (event.target === templateModal) closeTemplateModal(); });
    }
    if (!templateModal.isConnected) document.body.append(templateModal);
    templateModal.querySelector('[data-template-close]')?.focus();
    const list = templateModal.querySelector('[data-template-list]');
    const search = templateModal.querySelector('.contao-live-edit-template-search input');
    const editor = templateModal.querySelector('[data-template-source]');
    const aceSurface = templateModal.querySelector('[data-template-ace]');
    const status = templateModal.querySelector('[data-template-status]');
    const pathLabel = templateModal.querySelector('[data-template-path]');
    const save = templateModal.querySelector('[data-template-save]');
    const restore = templateModal.querySelector('[data-template-restore]');
    const currentSource = () => templateAce ? templateAce.getValue() : editor.value;
    const setSource = (value, path = '') => {
      editor.value = value;
      if (templateAce) {
        templateAce.setValue(value, -1);
        templateAce.session.setMode(path.endsWith('.html.twig') ? 'ace/mode/twig' : 'ace/mode/html');
      }
    };
    try {
      await loadTemplateAce();
      aceSurface.hidden = false; editor.hidden = true;
      if (!templateAce) {
        templateAce = window.ace.edit(aceSurface);
        templateAce.setTheme(document.documentElement.dataset.contaoLiveEditTheme === 'dark' ? 'ace/theme/dracula' : 'ace/theme/chrome');
        templateAce.setOptions({ fontSize: '13px', showPrintMargin: false, tabSize: 2, useSoftTabs: true, displayIndentGuides: true, wrap: false });
        templateAce.session.setUseWorker(false);
        templateAce.session.on('change', () => { status.classList.remove('is-error'); status.textContent = currentSource() === templateOriginalSource ? 'No unsaved changes' : 'Unsaved changes'; });
      }
    } catch (_) { aceSurface.hidden = true; editor.hidden = false; }
    const loadTemplate = async (path, button) => {
      if (path !== templateSelectedPath && currentSource() !== templateOriginalSource && !window.confirm('Discard unsaved template changes?')) return;
      status.textContent = 'Loading template…';
      try {
        const response = await fetch(appUrl(`/contao-live-edit/template-source?path=${encodeURIComponent(path)}`), { credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || 'Could not open template.');
        templateSelectedPath = path; templateOriginalSource = result.content; setSource(templateOriginalSource, path); editor.disabled = false; save.disabled = false; restore.disabled = !result.hasBackup;
        pathLabel.textContent = path; status.textContent = 'Saved source';
        list.querySelectorAll('button').forEach((item) => item.classList.toggle('is-selected', item === button));
        templateAce ? templateAce.focus() : editor.focus();
      } catch (error) { status.textContent = error.message; status.classList.add('is-error'); }
    };
    try {
      const response = await fetch(appUrl('/contao-live-edit/templates'), { credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Could not load templates.');
      list.replaceChildren();
      if (!result.templates.length) { const empty = document.createElement('p'); empty.className = 'contao-live-edit-library-message'; empty.textContent = 'No custom templates found in the project templates folder.'; list.append(empty); }
      for (const template of result.templates) {
        const button = document.createElement('button'); button.type = 'button'; button.textContent = template.path; button.dataset.templatePath = template.path;
        button.addEventListener('click', () => loadTemplate(template.path, button)); list.append(button);
      }
      search.oninput = () => list.querySelectorAll('button').forEach((button) => { button.hidden = !button.textContent.toLowerCase().includes(search.value.trim().toLowerCase()); });
      const query = new URLSearchParams(window.location.search).get('template');
      const recordTemplate = preferredPath || '';
      const defaultElementTemplate = recordType ? `ce_${recordType}` : '';
      const preferredNames = [recordTemplate, defaultElementTemplate, templateSelectedPath, query, document.documentElement.dataset.contaoLiveEditPageTemplate].filter(Boolean);
      const normalizeTemplateName = (name) => String(name)
        .replace(/^\/+/, '')
        .replace(/^templates\//i, '')
        .replace(/\.(html\.twig|html5|xhtml)$/i, '')
        .toLowerCase();
      const templateByName = (name) => {
        const target = normalizeTemplateName(name);
        if (!target) return null;
        return result.templates.find((item) => normalizeTemplateName(item.path) === target)
          || result.templates.find((item) => normalizeTemplateName(item.path).endsWith(`/${target}`))
          || result.templates.find((item) => normalizeTemplateName(item.path).split('/').pop() === target.split('/').pop());
      };
      const preferred = preferredNames.map(templateByName).find(Boolean);
      if (preferred) {
        await loadTemplate(preferred.path, [...list.querySelectorAll('button')].find((button) => button.dataset.templatePath === preferred.path));
      } else if (recordTemplate) {
        status.textContent = `No project template matches “${recordTemplate}”. Choose the template file from the list.`;
      }
    } catch (error) { list.textContent = error.message || 'Could not load templates.'; }
    editor.oninput = () => { status.classList.remove('is-error'); status.textContent = currentSource() === templateOriginalSource ? 'No unsaved changes' : 'Unsaved changes'; };
    save.onclick = async () => {
      if (!templateSelectedPath) return;
      save.disabled = true; status.classList.remove('is-error'); status.textContent = 'Saving…';
      try { const result = await request('/contao-live-edit/save-template', { path: templateSelectedPath, content: currentSource() }); templateOriginalSource = currentSource(); restore.disabled = !result.hasBackup; status.textContent = 'Template saved. Previous version is available to restore.'; }
      catch (error) { status.classList.add('is-error'); status.textContent = error.message || 'Could not save template.'; }
      finally { save.disabled = false; }
    };
    restore.onclick = async () => {
      if (!templateSelectedPath || !window.confirm('Restore the previous saved version of this template? The current source will become the new backup.')) return;
      restore.disabled = true; status.classList.remove('is-error'); status.textContent = 'Restoring previous version…';
      try {
        const result = await request('/contao-live-edit/restore-template', { path: templateSelectedPath });
        templateOriginalSource = result.content; setSource(templateOriginalSource, templateSelectedPath); restore.disabled = !result.hasBackup;
        status.textContent = 'Previous version restored. The version you replaced is now the backup.';
      } catch (error) { restore.disabled = false; status.classList.add('is-error'); status.textContent = error.message || 'Could not restore the previous template version.'; }
    };
  };


  window.addEventListener('beforeunload', (event) => {
    const hasUnsavedText = activeField && activeField.innerHTML !== originalMarkup;
    const hasUnsavedTemplate = templateModal?.isConnected && templateHasUnsavedChanges();
    if (!hasUnsavedText && !hasUnsavedTemplate && !popoverDirty) return;
    event.preventDefault();
    event.returnValue = '';
  });

  const placePopover = (node) => {
    const rect = node.getBoundingClientRect();
    const width = Math.min(360, window.innerWidth - 24);
    const left = Math.max(12, Math.min(rect.left, window.innerWidth - width - 12));
    const top = rect.bottom + 12 + 190 < window.innerHeight ? rect.bottom + 12 : Math.max(12, rect.top - 202);
    popover.style.left = `${left}px`;
    popover.style.top = `${top}px`;
  };

  const elementAtPoint = (selector, x, y, within = document) => [...within.querySelectorAll(selector)]
    .filter((candidate) => {
      if (candidate.closest('.contao-live-edit-inline-bar, .contao-live-edit-edit-popover')) return false;
      const rect = candidate.getBoundingClientRect();
      return x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom;
    })
    .sort((a, b) => {
      const aRect = a.getBoundingClientRect();
      const bRect = b.getBoundingClientRect();
      return (aRect.width * aRect.height) - (bRect.width * bRect.height);
    })[0] || null;

  const inlineTextField = (target) => {
    const markedField = target.closest(fields);
    if (markedField) return markedField;

    const editable = target.closest('[data-contao-live-edit-record][data-contao-live-edit-type]');
    if (!editable) return null;

    const caption = target.closest('figcaption');
    if (caption && editable.dataset.contaoLiveEditType === 'image' && editable.contains(caption)) {
      caption.dataset.inlineRecord = editable.dataset.contaoLiveEditRecord;
      caption.dataset.inlineField = 'caption';
      return caption;
    }

    const heading = target.closest('h1,h2,h3,h4,h5,h6');
    const fieldName = editable.dataset.contaoLiveEditType === 'headline' ? 'headline'
      : editable.dataset.contaoLiveEditType === 'text' && heading && editable.contains(heading) && !heading.closest('.rte') ? 'headline'
        : editable.dataset.contaoLiveEditType === 'text' ? 'text' : '';
    if (!fieldName || editable.closest('.contao-live-edit-inline-bar, .contao-live-edit-edit-popover')) return null;
    const field = 'headline' === fieldName && heading ? heading
      : 'text' === fieldName ? (editable.querySelector('.rte') || editable) : editable;
    field.dataset.inlineRecord = editable.dataset.contaoLiveEditRecord;
    field.dataset.inlineField = fieldName;
    return field;
  };

  const recordForTarget = (target) => target.closest('[data-contao-live-edit-record][data-contao-live-edit-type]');
  const hasDragType = (event, type) => Array.from(event.dataTransfer?.types || []).includes(type);
  const isContentDrag = (event) => hasDragType(event, 'application/x-contao-live-edit-element');
  const request = async (path, payload) => {
    const response = await fetch(appUrl(path), {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
      body: JSON.stringify({ ...payload, _token: token })
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'The content change could not be saved.');
    return result;
  };

  const addMoveHandle = (record) => {
    if (!isActive() || record.querySelector(':scope > .contao-live-edit-action-bar')) return;
    if ('static' === window.getComputedStyle(record).position) record.style.position = 'relative';
    const toolbar = document.createElement('div');
    toolbar.className = 'contao-live-edit-action-bar';
    toolbar.setAttribute('role', 'toolbar');
    toolbar.setAttribute('aria-label', 'Element actions');
    const makeAction = (className, label, icon, action) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = className;
      button.style.setProperty('background', 'transparent', 'important');
      button.style.setProperty('box-shadow', 'none', 'important');
      button.style.setProperty('border-color', 'transparent', 'important');
      button.title = label;
      button.setAttribute('aria-label', label);
      button.innerHTML = icon;
      button.addEventListener('click', (event) => { event.preventDefault(); event.stopPropagation(); action(button); });
      toolbar.append(button);
      return button;
    };
    const separator = () => { const rule = document.createElement('span'); rule.className = 'contao-live-edit-action-separator'; rule.setAttribute('aria-hidden', 'true'); toolbar.append(rule); };
    const icons = {
      drag: '<svg viewBox="0 0 20 20" aria-hidden="true"><circle cx="6" cy="5" r="1.3"/><circle cx="14" cy="5" r="1.3"/><circle cx="6" cy="10" r="1.3"/><circle cx="14" cy="10" r="1.3"/><circle cx="6" cy="15" r="1.3"/><circle cx="14" cy="15" r="1.3"/></svg>',
      settings: '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M8.2 2.5h3.6l.5 2a6 6 0 0 1 1.2.7l2-.6 1.8 3.1-1.5 1.5v1.5l1.5 1.5-1.8 3.1-2-.6a6 6 0 0 1-1.2.7l-.5 2H8.2l-.5-2a6 6 0 0 1-1.2-.7l-2 .6-1.8-3.1 1.5-1.5V9.2L2.7 7.7l1.8-3.1 2 .6a6 6 0 0 1 1.2-.7z"/><circle cx="10" cy="10" r="2.3"/></svg>',
      html: '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="m6.5 5-4 5 4 5M13.5 5l4 5-4 5M11.5 3 8.5 17"/></svg>',
      up: '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M10 16V4m-5 5 5-5 5 5"/></svg>',
      down: '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M10 4v12m5-5-5 5-5-5"/></svg>',
      show: '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M2 10s2.8-5 8-5 8 5 8 5-2.8 5-8 5-8-5-8-5Z"/><circle cx="10" cy="10" r="2.2"/></svg>',
      remove: '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M4 6h12m-10 0 .7 10.2h6.6L14 6M8 6V4h4v2m-3 3v4m2-4v4"/></svg>'
    };
    const handle = document.createElement('button');
    handle.type = 'button';
    handle.className = 'contao-live-edit-move-handle';
    handle.draggable = true;
    handle.style.setProperty('background', 'transparent', 'important');
    handle.style.setProperty('box-shadow', 'none', 'important');
    handle.style.setProperty('border-color', 'transparent', 'important');
    handle.title = 'Drag to rearrange';
    handle.setAttribute('aria-label', 'Drag to rearrange this element');
    handle.innerHTML = icons.drag;
    handle.addEventListener('click', (event) => event.stopPropagation());
    handle.addEventListener('dragstart', (event) => {
      event.stopPropagation();
      event.dataTransfer.setData('application/x-contao-live-edit-record', record.dataset.contaoLiveEditRecord);
      event.dataTransfer.effectAllowed = 'move';
      record.classList.add('contao-live-edit-is-moving');
    });
    handle.addEventListener('dragend', () => record.classList.remove('contao-live-edit-is-moving'));
    toolbar.append(handle);
    const sameParentRecords = () => [...document.querySelectorAll('[data-contao-live-edit-record][data-contao-live-edit-type]')]
      .filter((item) => item.dataset.contaoLiveEditParentId === record.dataset.contaoLiveEditParentId
        && item.dataset.contaoLiveEditParentTable === record.dataset.contaoLiveEditParentTable);
    const move = async (direction, button) => {
      const siblings = sameParentRecords();
      const index = siblings.indexOf(record);
      const anchor = siblings[index + (direction === 'up' ? -1 : 1)];
      if (!anchor) return;
      button.disabled = true;
      try {
        await request('/contao-live-edit/reorder-content', { id: record.dataset.contaoLiveEditRecord, anchorId: anchor.dataset.contaoLiveEditRecord, placement: direction === 'up' ? 'before' : 'after' });
        window.location.reload();
      } catch (error) { button.disabled = false; window.alert(error.message || 'Could not move this element.'); }
    };
    const moveUp = makeAction('contao-live-edit-action-move', 'Move element up', icons.up, (button) => move('up', button));
    const moveDown = makeAction('contao-live-edit-action-move', 'Move element down', icons.down, (button) => move('down', button));
    const refreshMoveState = () => {
      const siblings = sameParentRecords();
      const index = siblings.indexOf(record);
      moveUp.disabled = index <= 0;
      moveDown.disabled = index < 0 || index >= siblings.length - 1;
    };
    refreshMoveState();
    separator();
    makeAction('contao-live-edit-settings-handle', 'Edit element settings', icons.settings, () => openElementEditor(record));
    makeAction('contao-live-edit-html-handle', 'Edit HTML or template source', icons.html, () => openElementEditor(record, { html: true }));
    separator();
    const visibility = makeAction('contao-live-edit-action-visibility', 'Hide element', icons.show, async (button) => {
      const isHidden = record.dataset.contaoLiveEditInvisible === 'true';
      button.disabled = true;
      try {
        await request('/contao-live-edit/save-element-fields', { id: record.dataset.contaoLiveEditRecord, fields: { invisible: !isHidden } });
        record.dataset.contaoLiveEditInvisible = String(!isHidden);
        button.disabled = false;
        renderVisibility();
        if (isHidden) {
          revealContaoHiddenElements(record);
          setMessage('Element hidden in published view');
        } else {
          setMessage('Showing element…');
          window.location.reload();
        }
      } catch (error) { button.disabled = false; window.alert(error.message || 'Could not change element visibility.'); }
    });
    const renderVisibility = () => {
      const isHidden = record.dataset.contaoLiveEditInvisible === 'true';
      visibility.title = isHidden ? 'Show element' : 'Hide element';
      visibility.setAttribute('aria-label', visibility.title);
      visibility.setAttribute('aria-pressed', String(isHidden));
      visibility.innerHTML = isHidden
        ? '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M2 10s2.8-5 8-5 8 5 8 5-2.8 5-8 5-8-5-8-5Z"/><circle cx="10" cy="10" r="2.2"/><path d="m3 3 14 14"/></svg>'
        : icons.show;
    };
    renderVisibility();
    const remove = makeAction('contao-live-edit-action-remove', 'Remove element', icons.remove, async (button) => {
      if (!window.confirm('Remove this element from the page? This cannot be undone.')) return;
      button.disabled = true;
      try {
        await request('/contao-live-edit/delete-element', { id: record.dataset.contaoLiveEditRecord });
        record.remove();
        setMessage('Element removed');
      }
      catch (error) { button.disabled = false; window.alert(error.message || 'Could not remove this element.'); }
    });
    record.append(toolbar);
  };

  const prepareArticles = () => {
    const seen = new Set();
    const add = (article, id, url = '') => {
      if (!article || seen.has(id)) return;
      seen.add(id);
      article.classList.add('contao-live-edit-article');
      article.dataset.contaoLiveEditArticleUrl ||= url || appUrl(`/contao?do=article&table=tl_article&id=${encodeURIComponent(id)}`);
    };

    for (const article of document.querySelectorAll('.contao-live-edit-article')) {
      const idClass = [...article.classList].find((name) => /^contao-live-edit-article-\d+$/.test(name));
      if (idClass) add(article, idClass.slice('contao-live-edit-article-'.length), article.dataset.contaoLiveEditArticleUrl);
    }
    for (const record of document.querySelectorAll('[data-contao-live-edit-parent-table="tl_article"][data-contao-live-edit-parent-id]')) {
      const id = record.dataset.contaoLiveEditParentId;
      if (!/^\d+$/.test(id) || seen.has(id)) continue;
      const article = document.querySelector(`.contao-live-edit-article-${id}`)
        || document.getElementById(`article-${id}`)
        || record.closest('.mod_article')
        || record;
      add(article, id, record.dataset.contaoLiveEditArticleUrl);
    }
  };

  const addPageTemplateHandle = (footer) => {
    const pageTemplate = document.documentElement.dataset.contaoLiveEditPageTemplate;
    if (!isActive() || !pageTemplate || footer.querySelector(':scope > .contao-live-edit-page-template-handle')) return;
    if ('static' === window.getComputedStyle(footer).position) footer.style.position = 'relative';
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'contao-live-edit-html-handle contao-live-edit-page-template-handle';
    button.title = 'Edit page template';
    button.setAttribute('aria-label', button.title);
    button.innerHTML = '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="m6.5 5-4 5 4 5M13.5 5l4 5-4 5M11.5 3 8.5 17"/></svg>';
    button.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      openTemplateEditor(pageTemplate, 'page');
    });
    footer.append(button);
  };
  const addPageTemplateHandles = () => document.querySelectorAll('footer').forEach(addPageTemplateHandle);

  let hiddenElementsLoaded = false;
  const loadHiddenElements = async () => {
    if (hiddenElementsLoaded) return;
    hiddenElementsLoaded = true;
    prepareArticles();
    const pageId = document.querySelector('meta[name="contao-live-edit-page-id"]')?.content;
    if (!/^\d+$/.test(pageId || '') || Number(pageId) < 1) return;

    try {
      const response = await fetch(appUrl(`/contao-live-edit/hidden-elements?pageId=${encodeURIComponent(pageId)}`), { credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Could not load hidden elements.');
      const present = new Set([...document.querySelectorAll('[data-contao-live-edit-record]')].map((record) => record.dataset.contaoLiveEditRecord));
      for (const element of result.elements || []) {
        if (present.has(String(element.id))) continue;
        const siblings = [...document.querySelectorAll(`[data-contao-live-edit-parent-table="tl_article"][data-contao-live-edit-parent-id="${element.pid}"]`)]
          .sort((a, b) => Number(a.dataset.contaoLiveEditSorting || 0) - Number(b.dataset.contaoLiveEditSorting || 0));
        const next = siblings.find((sibling) => Number(sibling.dataset.contaoLiveEditSorting || 0) > element.sorting);
        const previous = [...siblings].reverse().find((sibling) => Number(sibling.dataset.contaoLiveEditSorting || 0) < element.sorting);
        if (element.html) {
          const rendered = document.createElement('template');
          rendered.innerHTML = element.html;
          const renderedRecord = rendered.content.querySelector(`[data-contao-live-edit-record="${CSS.escape(String(element.id))}"]`);
          if (renderedRecord) {
            renderedRecord.dataset.contaoLiveEditInvisible = 'true';
            renderedRecord.dataset.contaoLiveEditParentId = String(element.pid);
            renderedRecord.dataset.contaoLiveEditParentTable = 'tl_article';
            renderedRecord.dataset.contaoLiveEditSorting = String(element.sorting);
            renderedRecord.dataset.contaoLiveEditTemplate = element.template || `ce_${element.type}`;
            if (next?.parentElement) next.parentElement.insertBefore(rendered.content, next);
            else if (previous?.parentElement) previous.after(rendered.content);
            else {
              const article = document.querySelector(`.contao-live-edit-article-${element.pid}`)
                || document.getElementById(`article-${element.pid}`)
                || document.querySelector('.contao-live-edit-article');
              (article || document.body).append(rendered.content);
            }
            revealContaoHiddenElements(renderedRecord);
            addMoveHandle(renderedRecord);
            present.add(String(element.id));
            continue;
          }
        }
        const placeholder = document.createElement('div');
        placeholder.className = 'contao-live-edit-hidden-element';
        placeholder.dataset.contaoLiveEditRecord = String(element.id);
        placeholder.dataset.contaoLiveEditType = element.type;
        placeholder.dataset.contaoLiveEditParentId = String(element.pid);
        placeholder.dataset.contaoLiveEditParentTable = 'tl_article';
        placeholder.dataset.contaoLiveEditSorting = String(element.sorting);
        placeholder.dataset.contaoLiveEditInvisible = 'true';
        placeholder.dataset.contaoLiveEditTemplate = element.template || `ce_${element.type}`;
        placeholder.textContent = `${element.title || element.type} · Hidden in published view`;
        if (next?.parentElement) next.parentElement.insertBefore(placeholder, next);
        else if (previous?.parentElement) previous.after(placeholder);
        else {
          const article = document.querySelector(`.contao-live-edit-article-${element.pid}`)
            || document.getElementById(`article-${element.pid}`)
            || document.querySelector('.contao-live-edit-article');
          (article || document.body).append(placeholder);
        }
        revealContaoHiddenElements(placeholder);
        addMoveHandle(placeholder);
        present.add(String(element.id));
      }
    } catch (error) {
      console.warn(error.message || 'Could not load hidden elements.');
      hiddenElementsLoaded = false;
    }
  };

  const keyboardTargetState = new Map();
  const updateKeyboardTargets = (active) => {
    if (!active) {
      for (const [field, previousTabindex] of keyboardTargetState) {
        if (!field.isConnected) continue;
        if (null === previousTabindex) field.removeAttribute('tabindex');
        else field.setAttribute('tabindex', previousTabindex);
      }
      keyboardTargetState.clear();
      return;
    }

    const candidates = new Set(document.querySelectorAll(fields));
    prepareArticles();
    addPageTemplateHandles();
    void loadHiddenElements();
    for (const record of document.querySelectorAll('[data-contao-live-edit-record][data-contao-live-edit-type]')) {
      addMoveHandle(record);
      const field = inlineTextField(record);
      if (field) candidates.add(field);
      for (const caption of record.querySelectorAll('figcaption')) {
        const captionField = inlineTextField(caption);
        if (captionField) candidates.add(captionField);
      }
    }
    for (const field of candidates) {
      if (!keyboardTargetState.has(field)) keyboardTargetState.set(field, field.getAttribute('tabindex'));
      field.setAttribute('tabindex', '0');
    }
  };

  syncActivation();

  document.addEventListener('pointerover', (event) => {
    if (!isActive()) return;
    const footer = event.target.closest('footer');
    if (footer) addPageTemplateHandle(footer);
    const record = recordForTarget(event.target);
    if (record && !record.closest('.contao-live-edit-inline-bar, .contao-live-edit-edit-popover')) addMoveHandle(record);
  });

  document.addEventListener('dragover', (event) => {
    if (!isActive() || (!isContentDrag(event) && !hasDragType(event, 'application/x-contao-live-edit-record'))) return;
    const record = recordForTarget(event.target);
    if (!record) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = isContentDrag(event) ? 'copy' : 'move';
    document.querySelectorAll('.contao-live-edit-drop-before,.contao-live-edit-drop-after').forEach((node) => node.classList.remove('contao-live-edit-drop-before', 'contao-live-edit-drop-after'));
    const placement = event.clientY < record.getBoundingClientRect().top + record.getBoundingClientRect().height / 2 ? 'before' : 'after';
    record.classList.add(`contao-live-edit-drop-${placement}`);
  });

  document.addEventListener('dragleave', (event) => {
    if (event.target === document.documentElement) document.querySelectorAll('.contao-live-edit-drop-before,.contao-live-edit-drop-after').forEach((node) => node.classList.remove('contao-live-edit-drop-before', 'contao-live-edit-drop-after'));
  });

  document.addEventListener('drop', async (event) => {
    const record = recordForTarget(event.target);
    if (!isActive() || !record) return;
    const newType = event.dataTransfer?.getData('application/x-contao-live-edit-element');
    const movingId = event.dataTransfer?.getData('application/x-contao-live-edit-record');
    if (!newType && !movingId) return;
    event.preventDefault();
    event.stopPropagation();
    const rect = record.getBoundingClientRect();
    const placement = event.clientY < rect.top + rect.height / 2 ? 'before' : 'after';
    document.querySelectorAll('.contao-live-edit-drop-before,.contao-live-edit-drop-after').forEach((node) => node.classList.remove('contao-live-edit-drop-before', 'contao-live-edit-drop-after'));
    try {
      if (newType) {
        setMessage('Adding element…');
        await request('/contao-live-edit/insert-content', { type: newType, anchorId: record.dataset.contaoLiveEditRecord, placement });
        setMessage('Element added');
      } else {
        setMessage('Moving element…');
        await request('/contao-live-edit/reorder-content', { id: movingId, anchorId: record.dataset.contaoLiveEditRecord, placement });
        setMessage('Element moved');
      }
      window.setTimeout(() => window.location.reload(), 350);
    } catch (error) {
      setMessage(error.message || 'The content change could not be saved.', true);
    }
  }, true);

  const openLinkEditor = (link) => {
    const opener = document.activeElement;
    if (activeField && !finish(true)) return;
    if (!closePopover()) return;
    popoverOpener = opener;
    popover = document.createElement('form');
    popover.className = 'contao-live-edit-edit-popover contao-live-edit-link-popover';
    popover.setAttribute('role', 'dialog');
    popover.setAttribute('aria-modal', 'true');
    popover.setAttribute('tabindex', '-1');
    popover.setAttribute('aria-label', 'Edit link');
    popover.innerHTML = '<div class="contao-live-edit-popover-heading">Edit link</div>' +
      '<label>Text<input name="label" maxlength="255" required></label>' +
      '<label>URL<input name="url" maxlength="2048" placeholder="https://… or /contact" required></label>' +
      '<label>Title<input name="title" maxlength="255"></label>' +
      '<label>Lightbox group<input name="rel" maxlength="64" placeholder="e.g. gallery"></label>' +
      '<label class="contao-live-edit-popover-check"><input name="target" type="checkbox"> Open in a new tab</label>' +
      '<div class="contao-live-edit-popover-actions"><span class="contao-live-edit-popover-status" aria-live="polite"></span><button type="button" data-action="cancel">Cancel</button><button type="submit">Save link</button></div>';
    document.body.append(popover);
    popover.elements.label.value = link.textContent.trim();
    popover.elements.url.value = link.getAttribute('href') || '';
    popover.elements.title.value = link.getAttribute('title') || '';
    popover.elements.rel.value = link.getAttribute('rel') || '';
    popover.elements.target.checked = link.target === '_blank';
    trackPopoverChanges();
    placePopover(link);
    popover.elements.label.focus();
    popover.querySelector('[data-action="cancel"]').addEventListener('click', () => closePopover(true));
    popover.addEventListener('click', (event) => event.stopPropagation());
    popover.addEventListener('submit', async (event) => {
      event.preventDefault();
      const submit = popover.querySelector('[type="submit"]');
      const message = popover.querySelector('.contao-live-edit-popover-status');
      submit.disabled = true;
      message.textContent = 'Saving…';
      setPopoverSaving(true);
      try {
        const response = await fetch(appUrl('/contao-live-edit/save-link'), {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
          body: JSON.stringify({
            id: link.closest('[data-contao-live-edit-type="hyperlink"]')?.dataset.contaoLiveEditRecord || '',
            label: popover.elements.label.value,
            url: popover.elements.url.value,
            title: popover.elements.title.value,
            rel: popover.elements.rel.value,
            target: popover.elements.target.checked,
            _token: token
          })
        });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || 'Could not save this link.');
        link.textContent = popover.elements.label.value;
        link.setAttribute('href', popover.elements.url.value);
        link.target = popover.elements.target.checked ? '_blank' : '';
        if (popover.elements.title.value) link.setAttribute('title', popover.elements.title.value);
        else link.removeAttribute('title');
        if (popover.elements.rel.value) link.setAttribute('rel', popover.elements.rel.value);
        else link.removeAttribute('rel');
        setPopoverSaving(false);
        closePopover(true);
        setMessage('Saved');
        window.setTimeout(() => setMessage(''), 1200);
      } catch (error) {
        setPopoverSaving(false);
        submit.disabled = false;
        message.textContent = error.message || 'Could not save this link.';
        message.classList.add('is-error');
      }
    });
  };

  const openImageEditor = (image) => {
    const opener = document.activeElement;
    if (activeField && !finish(true)) return;
    if (!closePopover()) return;
    popoverOpener = opener;
    const imageRecord = image.closest('[data-contao-live-edit-type="image"]');

    if (!imageRecord?.dataset.contaoLiveEditRecord) {
      setMessage('Contao could not find an editable image element here.', true);
      return;
    }

    const caption = image.closest('figure')?.querySelector('figcaption')?.innerText.trim() || '';
    popover = document.createElement('form');
    popover.className = 'contao-live-edit-edit-popover contao-live-edit-image-modal';
    popover.setAttribute('role', 'dialog');
    popover.setAttribute('aria-modal', 'true');
    popover.setAttribute('tabindex', '-1');
    popover.setAttribute('aria-label', 'Edit image');
    popover.innerHTML = '<div class="contao-live-edit-image-modal-card">' +
      '<header class="contao-live-edit-image-modal-header"><div><span class="contao-live-edit-modal-kicker">IMAGE</span><h2>Replace or edit image</h2><p>Upload a new image and update its key display settings.</p></div><button type="button" class="contao-live-edit-modal-close" data-action="cancel" aria-label="Close">×</button></header>' +
      '<div class="contao-live-edit-image-modal-content"><div class="contao-live-edit-image-preview"><img alt="Current image preview"></div>' +
      '<div class="contao-live-edit-image-dropzone" tabindex="0" role="button" aria-label="Choose or drop an image"><span class="contao-live-edit-upload-icon" aria-hidden="true">↑</span><strong data-file-name>Drop an image here</strong><span>JPG, PNG, GIF, WebP or AVIF · up to 15 MB</span><div class="contao-live-edit-image-source-actions"><button type="button" data-action="browse">Upload image</button><button type="button" data-action="library">Choose from library</button></div><input name="file" type="file" accept="image/jpeg,image/png,image/gif,image/webp,image/avif" hidden></div>' +
      '<section class="contao-live-edit-image-library" data-image-library hidden aria-label="Contao file library"></section>' +
      '<div class="contao-live-edit-image-fields"><label>Alternative text<input name="alt" maxlength="255" placeholder="Describe the image"></label><label>Image title<input name="title" maxlength="255" placeholder="Optional title"></label><label class="contao-live-edit-caption-field">Caption<textarea name="caption" maxlength="500" rows="2" placeholder="Optional caption"></textarea></label></div></div>' +
      '<footer class="contao-live-edit-image-modal-footer"><span class="contao-live-edit-popover-status" aria-live="polite"></span><button type="button" data-action="cancel">Cancel</button><button type="submit">Save image</button></footer></div>';
    document.body.append(popover);
    const preview = popover.querySelector('.contao-live-edit-image-preview img');
    preview.src = image.currentSrc || image.src;
    popover.elements.alt.value = image.alt || '';
    popover.elements.title.value = image.title || '';
    popover.elements.caption.value = caption;
    trackPopoverChanges();

    const fileInput = popover.elements.file;
    const dropzone = popover.querySelector('.contao-live-edit-image-dropzone');
    const fileName = popover.querySelector('[data-file-name]');
    const uploadStatus = popover.querySelector('.contao-live-edit-popover-status');
    const libraryPanel = popover.querySelector('[data-image-library]');
    let selectedFile = null;
    let selectedUuid = '';
    let libraryFolders = [];

    const selectFile = (file) => {
      if (!file) return;
      if (!file.type.startsWith('image/')) {
        uploadStatus.textContent = 'Choose an image file.';
        uploadStatus.classList.add('is-error');
        return;
      }
      if (file.size > 15 * 1024 * 1024) {
        uploadStatus.textContent = 'This image is larger than 15 MB.';
        uploadStatus.classList.add('is-error');
        return;
      }
      if (imagePreviewUrl) URL.revokeObjectURL(imagePreviewUrl);
      selectedUuid = '';
      selectedFile = file;
      imagePreviewUrl = URL.createObjectURL(file);
      preview.src = imagePreviewUrl;
      fileName.textContent = file.name;
      dropzone.classList.add('has-file');
      popoverDirty = true;
      uploadStatus.textContent = '';
      uploadStatus.classList.remove('is-error');
    };

    popover.addEventListener('click', (event) => event.stopPropagation());
    popover.querySelectorAll('[data-action="cancel"]').forEach((button) => button.addEventListener('click', () => closePopover(true)));
    popover.querySelector('[data-action="browse"]').addEventListener('click', () => fileInput.click());
    const loadLibrary = async () => {
      libraryPanel.hidden = false;
      libraryPanel.replaceChildren();
      const loading = document.createElement('p');
      loading.className = 'contao-live-edit-library-message';
      loading.textContent = 'Loading your Contao files…';
      libraryPanel.append(loading);

      try {
        const folder = libraryFolders.at(-1) || '';
        const response = await fetch(appUrl(`/contao-live-edit/image-library${folder ? `?folder=${encodeURIComponent(folder)}` : ''}`), {
          credentials: 'same-origin',
          headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || 'Could not load the Contao file library.');

        const header = document.createElement('div');
        header.className = 'contao-live-edit-library-header';
        const title = document.createElement('strong');
        title.textContent = result.folder?.name || 'Contao file library';
        header.append(title);
        const navigation = document.createElement('div');
        navigation.className = 'contao-live-edit-library-navigation';
        if (libraryFolders.length) {
          const back = document.createElement('button');
          back.type = 'button';
          back.textContent = '← Back';
          back.addEventListener('click', () => { libraryFolders.pop(); loadLibrary(); });
          navigation.append(back);
        }
        const closeLibrary = document.createElement('button');
        closeLibrary.type = 'button';
        closeLibrary.textContent = 'Close';
        closeLibrary.addEventListener('click', () => { libraryPanel.hidden = true; });
        navigation.append(closeLibrary);
        header.append(navigation);

        const grid = document.createElement('div');
        grid.className = 'contao-live-edit-library-grid';
        for (const item of result.items) {
          const choice = document.createElement('button');
          choice.type = 'button';
          choice.className = item.type === 'folder' ? 'contao-live-edit-library-item is-folder' : 'contao-live-edit-library-item';
          if (item.type === 'folder') {
            choice.innerHTML = '<span class="contao-live-edit-library-folder-icon" aria-hidden="true">▰</span>';
            choice.addEventListener('click', () => { libraryFolders.push(item.uuid); loadLibrary(); });
          } else {
            const thumbnail = document.createElement('img');
            thumbnail.src = item.url;
            thumbnail.alt = '';
            thumbnail.loading = 'lazy';
            choice.append(thumbnail);
            choice.addEventListener('click', () => {
              if (imagePreviewUrl) URL.revokeObjectURL(imagePreviewUrl);
              imagePreviewUrl = null;
              selectedFile = null;
              selectedUuid = item.uuid;
              preview.src = item.url;
              fileName.textContent = `Selected: ${item.name}`;
              dropzone.classList.add('has-file');
              popoverDirty = true;
              uploadStatus.textContent = '';
              uploadStatus.classList.remove('is-error');
              libraryPanel.hidden = true;
            });
          }
          const label = document.createElement('span');
          label.textContent = item.name;
          choice.append(label);
          grid.append(choice);
        }
        libraryPanel.replaceChildren(header, grid);
        if (!result.items.length) {
          const empty = document.createElement('p');
          empty.className = 'contao-live-edit-library-message';
          empty.textContent = 'No folders or images in this location.';
          libraryPanel.append(empty);
        }
      } catch (error) {
        loading.textContent = error.message || 'Could not load the Contao file library.';
        loading.classList.add('is-error');
      }
    };
    popover.querySelector('[data-action="library"]').addEventListener('click', () => { libraryFolders = []; loadLibrary(); });
    fileInput.addEventListener('change', () => selectFile(fileInput.files?.[0]));
    dropzone.addEventListener('click', (event) => {
      if (!event.target.closest('button')) fileInput.click();
    });
    dropzone.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); fileInput.click(); }
    });
    dropzone.addEventListener('dragover', (event) => { event.preventDefault(); dropzone.classList.add('is-dragging'); });
    dropzone.addEventListener('dragleave', () => dropzone.classList.remove('is-dragging'));
    dropzone.addEventListener('drop', (event) => {
      event.preventDefault();
      dropzone.classList.remove('is-dragging');
      selectFile(event.dataTransfer?.files?.[0]);
    });
    popover.addEventListener('submit', async (event) => {
      event.preventDefault();
      const submit = popover.querySelector('[type="submit"]');
      submit.disabled = true;
      uploadStatus.textContent = 'Saving…';
      uploadStatus.classList.remove('is-error');
      setPopoverSaving(true);
      const formData = new FormData();
      formData.set('id', imageRecord.dataset.contaoLiveEditRecord);
      formData.set('alt', popover.elements.alt.value);
      formData.set('title', popover.elements.title.value);
      formData.set('caption', popover.elements.caption.value);
      formData.set('_token', token);
      if (selectedFile) formData.set('file', selectedFile);
      else if (selectedUuid) formData.set('fileUuid', selectedUuid);

      try {
        const response = await fetch(appUrl('/contao-live-edit/save-image'), {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'X-Requested-With': 'XMLHttpRequest' },
          body: formData
        });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || 'Could not save this image.');
        image.alt = result.alt;
        image.title = result.title;
        if (result.url) {
          image.src = `${result.url}?v=${Date.now()}`;
          image.removeAttribute('srcset');
          image.closest('picture')?.querySelectorAll('source').forEach((source) => source.removeAttribute('srcset'));
        }
        const figure = image.closest('figure');
        if (figure) {
          let figcaption = figure.querySelector('figcaption');
          if (result.caption && !figcaption) {
            figcaption = document.createElement('figcaption');
            figure.append(figcaption);
          }
          if (figcaption) {
            if (result.caption) figcaption.textContent = result.caption;
            else figcaption.remove();
          }
        }
        setPopoverSaving(false);
        closePopover(true);
        setMessage('Image saved');
        window.setTimeout(() => setMessage(''), 1400);
      } catch (error) {
        setPopoverSaving(false);
        submit.disabled = false;
        uploadStatus.textContent = error.message || 'Could not save this image.';
        uploadStatus.classList.add('is-error');
      }
    });
    popover.querySelector('[name="alt"]').focus();
  };

  const openElementEditor = async (record, { html = false } = {}) => {
    const opener = document.activeElement;
    if (activeField && !finish(true)) return;
    const id = record?.dataset.contaoLiveEditRecord;
    if (!id) return;
    if (!closePopover()) return;
    popoverOpener = opener;
    popover = document.createElement('form');
    popover.className = 'contao-live-edit-edit-popover contao-live-edit-element-modal';
    popover.setAttribute('role', 'dialog');
    popover.setAttribute('aria-modal', 'true');
    popover.setAttribute('tabindex', '-1');
    popover.setAttribute('aria-label', 'Edit content element');
    popover.innerHTML = '<div class="contao-live-edit-element-modal-card"><header class="contao-live-edit-element-header"><div><span class="contao-live-edit-modal-kicker">QUICK EDIT</span><h2>Element settings</h2><p>Edit the fields that matter here. Timing and visibility are just below.</p></div><button type="button" class="contao-live-edit-modal-close" data-action="cancel" aria-label="Close">×</button></header><div class="contao-live-edit-element-fields" data-element-fields><div class="contao-live-edit-library-message">Loading settings…</div></div><footer class="contao-live-edit-image-modal-footer"><div class="contao-live-edit-element-quick-actions"><button type="button" class="contao-live-edit-reorder-control" data-action="move-up" aria-label="Move element up" title="Move element up">↑</button><button type="button" class="contao-live-edit-reorder-control" data-action="move-down" aria-label="Move element down" title="Move element down">↓</button><button type="button" class="contao-live-edit-delete-element" data-action="delete" aria-label="Remove element" title="Remove element"><svg viewBox="0 0 20 20" aria-hidden="true"><path d="M4 6h12m-10 0 .7 10.2h6.6L14 6M8 6V4h4v2m-3 3v4m2-4v4"/></svg></button><button type="button" class="contao-live-edit-visibility-toggle" data-action="visibility" aria-pressed="false" aria-label="Hide element" title="Hide element"></button></div><span class="contao-live-edit-popover-status" aria-live="polite"></span><button type="button" data-action="cancel">Cancel</button><button type="submit">Save changes</button></footer></div>';
    document.body.append(popover);
    trackPopoverChanges();
    popover.addEventListener('click', (event) => event.stopPropagation());
    popover.querySelectorAll('[data-action="cancel"]').forEach((button) => button.addEventListener('click', () => closePopover(true)));
    const fieldPanel = popover.querySelector('[data-element-fields]');
    const status = popover.querySelector('.contao-live-edit-popover-status');
    const moveUpButton = popover.querySelector('[data-action="move-up"]');
    const moveDownButton = popover.querySelector('[data-action="move-down"]');
    const sameParentRecords = () => [...document.querySelectorAll('[data-contao-live-edit-record][data-contao-live-edit-type]')]
      .filter((item) => item.dataset.contaoLiveEditParentId === record.dataset.contaoLiveEditParentId
        && item.dataset.contaoLiveEditParentTable === record.dataset.contaoLiveEditParentTable);
    const refreshMoveButtons = () => {
      const siblings = sameParentRecords();
      const index = siblings.findIndex((item) => item.dataset.contaoLiveEditRecord === id);
      moveUpButton.disabled = index <= 0;
      moveDownButton.disabled = index < 0 || index >= siblings.length - 1;
    };
    const moveElement = async (direction, button) => {
      const siblings = sameParentRecords();
      const index = siblings.findIndex((item) => item.dataset.contaoLiveEditRecord === id);
      const anchor = siblings[index + (direction === 'up' ? -1 : 1)];
      if (!anchor || !closePopover()) return;
      setMessage(`Moving element ${direction}…`);
      try {
        await request('/contao-live-edit/reorder-content', {
          id,
          anchorId: anchor.dataset.contaoLiveEditRecord,
          placement: direction === 'up' ? 'before' : 'after'
        });
        setMessage('Element moved');
        window.location.reload();
      } catch (error) {
        setMessage(error.message || 'Could not move this element.', true);
      }
    };
    refreshMoveButtons();
    moveUpButton.addEventListener('click', () => moveElement('up', moveUpButton));
    moveDownButton.addEventListener('click', () => moveElement('down', moveDownButton));
    popover.querySelector('[data-action="delete"]').addEventListener('click', async () => {
      if (popover.dataset.saving === 'true') return;
      const message = popoverDirty
        ? 'Remove this element and discard its unsaved settings? This cannot be undone.'
        : 'Remove this element from the page? This cannot be undone.';
      if (!window.confirm(message)) return;
      closePopover(true);
      setMessage('Removing element…');
      try {
        await request('/contao-live-edit/delete-element', { id });
        record.remove();
        setMessage('Element removed');
      }
      catch (error) { setMessage(error.message || 'Could not remove this element.', true); }
    });

    const visibilityButton = popover.querySelector('[data-action="visibility"]');
    const renderVisibilityButton = (hidden) => {
      visibilityButton.dataset.hidden = String(hidden);
      visibilityButton.setAttribute('aria-pressed', String(hidden));
      visibilityButton.setAttribute('aria-label', hidden ? 'Show element' : 'Hide element');
      visibilityButton.title = hidden ? 'Show element' : 'Hide element';
      visibilityButton.innerHTML = hidden
        ? '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M2.5 10s2.7-5 7.5-5 7.5 5 7.5 5-2.7 5-7.5 5-7.5-5-7.5-5Z"/><circle cx="10" cy="10" r="2.2"/><path d="m3 3 14 14"/></svg>'
        : '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M2.5 10s2.7-5 7.5-5 7.5 5 7.5 5-2.7 5-7.5 5-7.5-5-7.5-5Z"/><circle cx="10" cy="10" r="2.2"/></svg>';
    };
    visibilityButton.addEventListener('click', () => {
      popoverDirty = true;
      renderVisibilityButton(visibilityButton.dataset.hidden !== 'true');
    });

    const controlFor = (field) => {
      const wrapper = document.createElement(field.richText || field.name === 'cssID' || ['listWizard', 'rowWizard', 'tableWizard'].includes(field.widget) ? 'div' : 'label');
      wrapper.className = 'contao-live-edit-element-field';
      if (field.dependencyGroups?.length) wrapper.dataset.dependencyGroups = JSON.stringify(field.dependencyGroups);
      if (field.name === 'cssID') wrapper.classList.add('is-cssid-pair');
      if (field.widget === 'checkbox' && !field.options?.length) wrapper.classList.add('is-toggle-field');
      if (field.advanced) wrapper.classList.add('is-advanced');
      const title = document.createElement('span');
      title.className = 'contao-live-edit-element-field-title';
      title.textContent = popover.dataset.editorMode === 'description-list' && field.name === 'data' ? 'Terms and descriptions' : popover.dataset.editorMode === 'markdown' && field.name === 'code' ? 'Markdown' : field.name === 'highlight' && popover.dataset.editorMode === 'code' ? 'Syntax' : field.label || field.name;
      if (field.name !== 'cssID') wrapper.append(title);
      if (field.richText) {
        const sourceToggle = document.createElement('button');
        sourceToggle.type = 'button'; sourceToggle.className = 'contao-live-edit-html-toggle';
        sourceToggle.textContent = 'Edit HTML'; sourceToggle.setAttribute('aria-label', `Edit ${field.label || field.name} as HTML`);
        wrapper.append(sourceToggle);
      }
      let input;
      if (field.widget === 'datetime') {
        input = document.createElement('input'); input.type = 'datetime-local';
        const timestamp = Number(field.value);
        if (timestamp > 0) { const date = new Date(timestamp * 1000); input.value = new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16); }
        else input.value = '';
      } else if (field.widget === 'fileTree') {
        input = document.createElement('input'); input.type = 'hidden'; input.value = JSON.stringify(Array.isArray(field.value) ? field.value : (field.value ? [field.value] : []));
      } else if (field.name === 'cssID' && field.value && typeof field.value === 'object') {
        input = document.createElement('span'); input.className = 'contao-live-edit-element-paired-fields';
        [['CSS ID', 'id'], ['CSS class', 'class']].forEach(([label, key]) => {
          const part = document.createElement('label'); part.className = 'contao-live-edit-element-paired-field';
          const partLabel = document.createElement('span'); partLabel.textContent = label;
          const partInput = document.createElement('input'); partInput.type = 'text'; partInput.value = String(field.value[key] ?? ''); partInput.dataset.cssIdField = field.name; partInput.dataset.cssIdKey = key;
          part.append(partLabel, partInput); input.append(part);
        });
      } else if (field.widget === 'imageSize') {
        input = document.createElement('span'); input.className = 'contao-live-edit-element-image-size';
        [['Width', 'width'], ['Height', 'height']].forEach(([label, key]) => {
          const part = document.createElement('span'); part.className = 'contao-live-edit-element-image-size-part';
          const partLabel = document.createElement('span'); partLabel.textContent = label;
          const partInput = document.createElement('input'); partInput.type = 'number'; partInput.min = '0'; partInput.placeholder = 'Auto'; partInput.value = String(field.value[key] ?? ''); partInput.dataset.imageSizeField = field.name; partInput.dataset.imageSizeKey = key;
          part.append(partLabel, partInput); input.append(part);
        });
        const mode = document.createElement('span'); mode.className = 'contao-live-edit-element-image-size-part';
        const modeLabel = document.createElement('span'); modeLabel.textContent = 'Preset / fit';
        const modeSelect = document.createElement('select'); modeSelect.dataset.imageSizeField = field.name; modeSelect.dataset.imageSizeKey = 'mode';
        const defaultOption = document.createElement('option'); defaultOption.value = ''; defaultOption.textContent = 'Custom dimensions'; modeSelect.append(defaultOption);
        let currentGroup = null; let optionGroup = null;
        for (const optionData of field.options || []) {
          if (optionData.group && optionData.group !== currentGroup) { currentGroup = optionData.group; optionGroup = document.createElement('optgroup'); optionGroup.label = currentGroup; modeSelect.append(optionGroup); }
          const option = document.createElement('option'); option.value = optionData.value; option.textContent = optionData.label; (optionData.group ? optionGroup : modeSelect).append(option);
        }
        modeSelect.value = String(field.value.mode ?? ''); mode.append(modeLabel, modeSelect); input.append(mode);
      } else if (field.name === 'module' || ((['select', 'radio', 'pageTree', 'radioTable', 'selectTree'].includes(field.widget) || (field.options?.length && !['checkbox', 'fileTree', 'inputUnit', 'imageSize', 'text', 'textarea', 'listWizard', 'rowWizard', 'tableWizard'].includes(field.widget))) && field.options?.length)) {
        input = document.createElement('select');
        input.multiple = Boolean(field.multiple);
        if (field.widget === 'select' && !input.multiple) {
          const blank = document.createElement('option'); blank.value = ''; blank.textContent = 'Choose…'; input.append(blank);
        }
        for (const option of field.options) {
          const item = document.createElement('option'); item.value = option.value; item.textContent = option.label; input.append(item);
        }
        if (input.multiple) for (const option of input.options) option.selected = (Array.isArray(field.value) ? field.value : [field.value]).map(String).includes(option.value);
        else input.value = String(field.value ?? '');
      } else if (field.widget === 'rowWizard' && field.columns?.length) {
        input = document.createElement('div'); input.className = 'contao-live-edit-wizard-editor';
        const rows = document.createElement('div'); rows.className = 'contao-live-edit-wizard-rows';
        const columns = popover.dataset.editorMode === 'description-list' && field.name === 'data'
          ? field.columns.map((column) => ({ ...column, label: column.name === 'key' ? 'Term' : column.name === 'value' ? 'Description' : column.label }))
          : field.columns;
        const sourceRows = Array.isArray(field.value) ? field.value : [];
        const appendRow = (value = {}) => {
          const row = document.createElement('div'); row.className = 'contao-live-edit-wizard-row';
          for (const column of columns) {
            const cell = document.createElement('label'); cell.className = 'contao-live-edit-wizard-cell';
            const caption = document.createElement('span'); caption.textContent = column.label;
            const cellInput = document.createElement('input'); cellInput.type = 'text';
            cellInput.value = String(Array.isArray(value) ? value[columns.indexOf(column)] ?? '' : value?.[column.name] ?? '');
            cellInput.dataset.wizardField = field.name; cellInput.dataset.wizardColumn = column.name;
            cell.append(caption, cellInput); row.append(cell);
          }
          const remove = document.createElement('button'); remove.type = 'button'; remove.className = 'contao-live-edit-wizard-remove'; remove.textContent = '×'; remove.title = 'Remove row';
          remove.addEventListener('click', () => row.remove()); row.append(remove); rows.append(row);
        };
        sourceRows.forEach(appendRow);
        const add = document.createElement('button'); add.type = 'button'; add.className = 'contao-live-edit-wizard-add'; add.textContent = '＋ Add row'; add.addEventListener('click', () => appendRow());
        input.append(rows, add);
      } else if (field.widget === 'listWizard') {
        input = document.createElement('div'); input.className = 'contao-live-edit-wizard-editor is-list-wizard';
        const rows = document.createElement('div'); rows.className = 'contao-live-edit-wizard-rows';
        const appendRow = (value = '') => {
          const row = document.createElement('div'); row.className = 'contao-live-edit-wizard-row';
          const cell = document.createElement('input'); cell.type = 'text'; cell.value = String(value); cell.dataset.wizardField = field.name; cell.dataset.wizardColumn = 'value';
          const remove = document.createElement('button'); remove.type = 'button'; remove.className = 'contao-live-edit-wizard-remove'; remove.textContent = '×'; remove.title = 'Remove item';
          remove.addEventListener('click', () => row.remove()); row.append(cell, remove); rows.append(row);
        };
        (Array.isArray(field.value) ? field.value : []).forEach(appendRow);
        const add = document.createElement('button'); add.type = 'button'; add.className = 'contao-live-edit-wizard-add'; add.textContent = '＋ Add item'; add.addEventListener('click', () => appendRow());
        input.append(rows, add);
      } else if (field.widget === 'textarea' || ['rowWizard', 'tableWizard'].includes(field.widget) || Array.isArray(field.value)) {
        input = document.createElement('textarea'); input.rows = ['rowWizard', 'tableWizard'].includes(field.widget) ? 5 : 4;
        if (['rowWizard', 'tableWizard'].includes(field.widget)) input.value = (Array.isArray(field.value) ? field.value : []).map((row) => (Array.isArray(row) ? row : Object.values(row || {})).map(String).join('\t')).join('\n');
        else if (Array.isArray(field.value)) { input.value = JSON.stringify(field.value ?? [], null, 2); input.dataset.jsonStructuredValue = 'true'; }
        else input.value = String(field.value ?? '');
        if (field.richText) { input.classList.add('contao-live-edit-native-rte'); input.rows = 9; }
        if (['code', 'html', 'unfilteredHtml'].includes(field.name)) { input.classList.add('contao-live-edit-source-editor'); input.rows = field.name === 'code' ? 18 : 14; input.spellcheck = false; wrapper.classList.add('is-source-field'); }
        if (field.name === 'markdownSource' || field.name === 'highlight') wrapper.classList.add('is-quick-select');
      } else if (field.widget === 'inputUnit') {
        input = document.createElement('span'); input.className = 'contao-live-edit-element-input-unit';
        const amount = document.createElement('input'); amount.type = 'text'; amount.value = String(field.value?.value ?? ''); amount.dataset.unitValue = field.name;
        const unit = document.createElement('select'); unit.dataset.unitName = field.name;
        for (const option of field.options || []) { const item = document.createElement('option'); item.value = option.value; item.textContent = option.label; unit.append(item); }
        unit.value = String(field.value?.unit ?? ''); input.append(amount, unit);
      } else if (field.widget === 'checkbox' && field.options?.length) {
        input = document.createElement('span'); input.className = 'contao-live-edit-element-check-options';
        for (const option of field.options) {
          const choice = document.createElement('span'); choice.className = 'contao-live-edit-element-check-option';
          const box = document.createElement('input'); box.type = 'checkbox'; box.value = option.value; box.dataset.choiceField = field.name;
          box.checked = Array.isArray(field.value) && field.value.map(String).includes(option.value);
          const label = document.createElement('span'); label.textContent = option.label; choice.append(box, label); input.append(choice);
        }
      } else if (field.widget === 'checkbox') {
        input = document.createElement('input'); input.type = 'checkbox';
        input.checked = Array.isArray(field.value) ? field.value.length > 0 : Boolean(field.value);
      } else {
        const arrayValue = Array.isArray(field.value);
        input = document.createElement(arrayValue ? 'textarea' : 'input');
        if (!arrayValue) input.type = 'text';
        input.value = arrayValue ? JSON.stringify(field.value, null, 2) : String(field.value ?? '');
        if (arrayValue) input.rows = 4;
        if (field.maxlength) input.maxLength = field.maxlength;
      }
      if (input.matches?.('input,textarea,select')) input.name = field.name;
      input.dataset.widget = field.widget; input.dataset.options = JSON.stringify(field.options || []);
      if (field.required && input.matches?.('input,textarea,select') && input.type !== 'hidden') { input.dataset.conditionalRequired = 'true'; input.required = !field.dependencyGroups?.length; }
      wrapper.append(input);
      if (field.description && !(popover.dataset.editorMode === 'markdown' && field.name === 'code')) { const hint = document.createElement('small'); hint.textContent = field.description; wrapper.append(hint); }
      if (field.widget === 'fileTree') {
        const selectedView = document.createElement('div'); selectedView.className = 'contao-live-edit-element-selected-files';
        const renderSelected = () => {
          selectedView.replaceChildren();
          let selected = []; try { selected = JSON.parse(input.value || '[]'); } catch {}
          for (const uuid of selected) {
            const item = (field.selectedFiles || []).find((file) => file.uuid === uuid);
            const card = document.createElement('div'); card.className = 'contao-live-edit-element-selected-file';
            if (item?.type === 'image' && item.url) { const image = document.createElement('img'); image.src = item.url; image.alt = item.name; card.append(image); }
            else { const fileIcon = document.createElement('span'); fileIcon.className = 'contao-live-edit-element-file-icon'; fileIcon.textContent = '▤'; card.append(fileIcon); }
            const name = document.createElement('span'); name.textContent = item?.name || 'Selected file'; card.append(name);
            const remove = document.createElement('button'); remove.type = 'button'; remove.setAttribute('aria-label', `Remove ${item?.name || 'selected file'}`); remove.textContent = '×';
            remove.addEventListener('click', () => { input.value = JSON.stringify(selected.filter((value) => value !== uuid)); renderSelected(); }); card.append(remove); selectedView.append(card);
          }
          if (!selected.length) { const empty = document.createElement('span'); empty.className = 'contao-live-edit-element-file-empty'; empty.textContent = 'No file selected'; selectedView.append(empty); }
        };
        renderSelected();
        const choose = document.createElement('button'); choose.type = 'button'; choose.className = 'contao-live-edit-element-file-picker'; choose.textContent = 'Choose from Contao files';
        const library = document.createElement('div'); library.className = 'contao-live-edit-element-file-library'; library.hidden = true;
        const folders = [];
        const load = async () => {
          library.hidden = false; library.replaceChildren();
          try {
            const folder = folders.at(-1) || '';
            const response = await fetch(appUrl(`/contao-live-edit/image-library?all=1${folder ? `&folder=${encodeURIComponent(folder)}` : ''}`), { credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } });
            const result = await response.json(); if (!response.ok) throw new Error(result.error || 'Could not load files.');
            const heading = document.createElement('div'); heading.className = 'contao-live-edit-element-library-heading';
            const title = document.createElement('strong'); title.textContent = result.folder?.name || 'Contao file library'; heading.append(title);
            if (folders.length) { const back = document.createElement('button'); back.type = 'button'; back.textContent = '← Back'; back.addEventListener('click', () => { folders.pop(); load(); }); heading.append(back); }
            const close = document.createElement('button'); close.type = 'button'; close.textContent = 'Close'; close.addEventListener('click', () => { library.hidden = true; }); heading.append(close); library.append(heading);
            for (const item of result.items) {
              const choice = document.createElement('button'); choice.type = 'button'; choice.className = `contao-live-edit-element-file-choice${item.type === 'folder' ? ' is-folder' : ''}`;
              if (item.type === 'image' && item.url) { const thumbnail = document.createElement('img'); thumbnail.src = item.url; thumbnail.alt = ''; choice.append(thumbnail); }
              const name = document.createElement('span'); name.textContent = item.type === 'folder' ? `▰ ${item.name}` : item.name; choice.append(name);
              if (item.type === 'folder') choice.addEventListener('click', () => { folders.push(item.uuid); load(); });
              else choice.addEventListener('click', () => {
                let selected; try { selected = JSON.parse(input.value || '[]'); } catch { selected = []; }
                if (!Array.isArray(selected)) selected = [];
                selected = field.multiple ? (selected.includes(item.uuid) ? selected.filter((uuid) => uuid !== item.uuid) : [...selected, item.uuid]) : [item.uuid];
                input.value = JSON.stringify(selected); input.dispatchEvent(new Event('input', { bubbles: true }));
                field.selectedFiles = field.selectedFiles || [];
                field.selectedFiles = field.selectedFiles.filter((file) => file.uuid !== item.uuid);
                field.selectedFiles.push({ uuid: item.uuid, name: item.name, type: item.type, url: item.url });
                renderSelected();
                choice.classList.toggle('is-selected', selected.includes(item.uuid));
                if (!field.multiple) library.hidden = true;
              });
              library.append(choice);
            }
            if (!result.items.length) { const empty = document.createElement('small'); empty.textContent = 'No files in this folder.'; library.append(empty); }
          } catch (error) { const message = document.createElement('small'); message.textContent = error.message || 'Could not load files.'; library.replaceChildren(message); }
        };
        choose.addEventListener('click', load); wrapper.append(input, selectedView, choose, library);
      }
      return wrapper;
    };
    const appendFields = (container, fields) => {
      const imageSelectorNames = new Set(fields.filter((field) => field.name === 'addImage' && field.widget === 'checkbox').map((field) => field.name));
      const imageOptions = [];
      const normalFields = [];
      for (const field of fields) {
        const dependsOnImageToggle = field.dependencyGroups?.some((group) => group.some((condition) => imageSelectorNames.has(condition.field)));
        (dependsOnImageToggle ? imageOptions : normalFields).push(field);
      }
      const dates = [];
      const orderedFields = [];
      for (let index = 0; index < normalFields.length; index++) {
        const field = normalFields[index];
        if (field.name === 'start' && normalFields[index + 1]?.name === 'stop') dates.push(field, normalFields[++index]);
        else {
          orderedFields.push(field);
          if (imageSelectorNames.has(field.name)) orderedFields.push(...imageOptions.splice(0));
        }
      }
      orderedFields.push(...imageOptions, ...dates);
      for (let index = 0; index < orderedFields.length; index++) {
        const field = orderedFields[index];
        if (field.name === 'start' && orderedFields[index + 1]?.name === 'stop') {
          const dates = document.createElement('div'); dates.className = 'contao-live-edit-element-date-range';
          dates.append(controlFor(field), controlFor(orderedFields[++index])); container.append(dates);
        } else container.append(controlFor(field));
      }
    };

    try {
      const response = await fetch(appUrl(`/contao-live-edit/element-fields/${encodeURIComponent(id)}`), { credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } });
      const contentType = response.headers.get('content-type') || '';
      if (response.redirected || !contentType.includes('application/json')) {
        if (response.redirected) throw new Error('Your Contao session may have expired. Sign in again, reload the page, and reopen Element Settings.');
        throw new Error(`Element settings could not be loaded (server returned ${response.status}, not JSON). Reload the page and try again; if it continues, check the Contao error log.`);
      }
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Could not load element settings.');
      const editorMode = result.editorMode || 'generic';
      popover.dataset.editorMode = editorMode;
      popover.classList.toggle('is-wide', ['code', 'markdown', 'description-list', 'html'].includes(editorMode));
      popover.classList.toggle('is-code-editor', editorMode === 'code');
      renderVisibilityButton(Boolean(result.invisible));
      const type = record.dataset.contaoLiveEditType;
      const videoType = ['youtube', 'vimeo'].includes(type);
      const titles = { code: 'Edit code', markdown: 'Edit Markdown', 'description-list': 'Edit description list', html: 'Edit HTML', toplink: 'Edit top link' };
      const guidance = { code: 'Edit the source and choose its syntax from the quick selector.', markdown: 'Choose a source, then edit the Markdown content or select a source file.', 'description-list': 'Edit each term and description as a separate row.', html: 'Edit the HTML source directly.', toplink: 'Change the label used by the back-to-top link.' };
      popover.querySelector('h2').textContent = result.fields.length ? (videoType ? `Set ${type === 'youtube' ? 'YouTube' : 'Vimeo'} video` : titles[editorMode] || `${type.replaceAll('_', ' ')} settings`) : 'No editable fields';
      popover.querySelector('.contao-live-edit-element-header p').textContent = videoType ? 'Paste the video link, check the preview, then save.' : guidance[editorMode] || 'Edit the key fields here. Open Advanced settings for the rest of Contao’s options.';
      fieldPanel.replaceChildren();
      const mainFields = videoType ? result.fields.filter((field) => [type, 'titleText'].includes(field.name)) : result.fields.filter((field) => !field.advanced);
      const extraFields = videoType ? result.fields.filter((field) => !mainFields.includes(field)) : result.fields.filter((field) => field.advanced);
      let videoPreview = null;
      if (videoType) {
        videoPreview = document.createElement('div'); videoPreview.className = 'contao-live-edit-element-video-preview';
        const updateVideoPreview = (value) => {
          const match = value.match(/(?:youtu\.be\/|youtube(?:-nocookie)?\.com\/(?:watch\?v=|embed\/|shorts\/))([\w-]{6,})/i);
          const vimeo = value.match(/vimeo\.com\/(?:video\/)?(\d+)/i);
          const youtubeId = match?.[1] || (/^[\w-]{11}$/.test(value) ? value : '');
          const vimeoId = vimeo?.[1] || (/^\d{1,12}$/.test(value) ? value : '');
          const source = type === 'youtube' && youtubeId ? `https://www.youtube-nocookie.com/embed/${youtubeId}` : type === 'vimeo' && vimeoId ? `https://player.vimeo.com/video/${vimeoId}` : '';
          videoPreview.replaceChildren();
          if (source) { const frame = document.createElement('iframe'); frame.src = source; frame.title = 'Video preview'; frame.loading = 'lazy'; frame.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share'; frame.allowFullscreen = true; videoPreview.append(frame); }
          else { const note = document.createElement('span'); note.textContent = 'Enter a valid video URL to preview it'; videoPreview.append(note); }
        };
        fieldPanel.append(videoPreview);
        for (const field of mainFields) {
          const displayField = field.name === type ? { ...field, label: `${type === 'youtube' ? 'YouTube' : 'Vimeo'} video URL`, value: field.value ? (type === 'youtube' ? `https://www.youtube.com/watch?v=${field.value}` : `https://vimeo.com/${field.value}`) : '' } : field;
          const control = controlFor(displayField); fieldPanel.append(control);
          if (field.name === type) control.querySelector('input,textarea,select')?.addEventListener('input', (event) => updateVideoPreview(event.target.value));
        }
        updateVideoPreview(String(mainFields.find((field) => field.name === type)?.value || ''));
      } else appendFields(fieldPanel, mainFields);
      if (extraFields.length) {
        const details = document.createElement('details'); details.className = 'contao-live-edit-element-extra';
        const summary = document.createElement('summary'); summary.textContent = `Advanced settings · ${extraFields.length} fields`; details.append(summary);
        appendFields(details, extraFields);
        fieldPanel.append(details);
      }
      const refreshDependentFields = () => {
        for (const dependent of fieldPanel.querySelectorAll('[data-dependency-groups]')) {
          let groups = []; try { groups = JSON.parse(dependent.dataset.dependencyGroups); } catch {}
          const active = groups.some((group) => group.every((condition) => {
            const selector = fieldPanel.querySelector(`[name="${CSS.escape(condition.field)}"]`);
            if (!selector) return false;
            const actual = selector.type === 'checkbox' ? selector.checked : selector.value;
            return typeof condition.value === 'boolean' ? Boolean(actual) === condition.value : String(actual) === String(condition.value);
          }));
          dependent.hidden = !active;
          dependent.querySelectorAll('[data-conditional-required="true"]').forEach((control) => { control.required = active; });
        }
      };
      fieldPanel.addEventListener('change', refreshDependentFields);
      fieldPanel.addEventListener('input', refreshDependentFields);
      refreshDependentFields();
      const richTextareas = [...fieldPanel.querySelectorAll('textarea.contao-live-edit-native-rte')];
      if (richTextareas.length && window.hugerte?.init) {
        popover.classList.add('has-hugerte-editor');
        for (const textarea of richTextareas) {
          textarea.id = `contao-live-edit-rte-${id}-${textarea.name}`;
          const editorOptions = {
            target: textarea,
            height: 300,
            branding: false,
            promotion: false,
            statusbar: false,
            language: document.documentElement.lang || 'en',
            element_format: 'html',
            entities: '160,nbsp,60,lt,62,gt,173,shy',
            skin: document.documentElement.dataset.contaoLiveEditTheme === 'dark' ? 'oxide-dark' : 'oxide',
            plugins: 'autosave charmap code fullscreen help image importcss link lists searchreplace stripnbsp table visualblocks visualchars',
            menubar: false,
            toolbar_mode: 'sliding',
            toolbar: 'link unlink | image | blocks | bold italic | alignleft aligncenter alignright | bullist numlist | code',
            extended_valid_elements: 'q[cite|class|title],article,section,hgroup,figure,figcaption',
            contextmenu: false,
            paste_data_images: false,
            browser_spellcheck: true,
            importcss_append: true,
            content_style: document.documentElement.dataset.contaoLiveEditTheme === 'dark'
              ? 'body{background:#202427;color:#e8e9e7;font-family:system-ui,sans-serif;font-size:14px;line-height:1.6;padding:8px 12px}a{color:#ff7900}'
              : 'body{background:#fff;color:#293d32;font-family:system-ui,sans-serif;font-size:14px;line-height:1.6;padding:8px 12px}a{color:#c75b22}',
            setup: (editor) => editor.on('change input undo redo', () => { textarea.value = editor.getContent(); textarea.dispatchEvent(new Event('input', { bubbles: true })); }),
          };
          const sourceToggle = textarea.closest('.contao-live-edit-element-field')?.querySelector('.contao-live-edit-html-toggle');
          const initVisualEditor = async () => { await window.hugerte.init(editorOptions); };
          try {
            await initVisualEditor();
            sourceToggle?.addEventListener('click', async () => {
              const editor = window.hugerte.get(textarea.id);
              if (editor) {
                textarea.value = editor.getContent();
                editor.remove();
                textarea.classList.add('is-html-source');
                sourceToggle.textContent = 'Visual editor';
                sourceToggle.setAttribute('aria-label', `Return to visual editing for ${textarea.name}`);
                textarea.focus();
              } else {
                textarea.classList.remove('is-html-source');
                try {
                  await initVisualEditor();
                  sourceToggle.textContent = 'Edit HTML';
                  sourceToggle.setAttribute('aria-label', `Edit ${textarea.name} as HTML`);
                } catch (error) {
                  textarea.classList.add('is-html-source');
                  console.warn('Contao rich-text editor could not be initialized.', error);
                }
              }
            });
          } catch (error) { console.warn('Contao rich-text editor could not be initialized.', error); }
        }
      }
      if (!result.fields.length) { const empty = document.createElement('p'); empty.className = 'contao-live-edit-library-message'; empty.textContent = 'This element has no editable fields in its Contao configuration.'; fieldPanel.append(empty); }
    } catch (error) {
      fieldPanel.textContent = error.message || 'Could not load element settings.';
      fieldPanel.classList.add('is-error');
      return;
    }

    popover.addEventListener('submit', async (event) => {
      event.preventDefault();
      const submit = popover.querySelector('[type="submit"]'); submit.disabled = true; status.textContent = 'Saving…'; status.classList.remove('is-error');
      setPopoverSaving(true);
      const values = {};
      for (const input of fieldPanel.querySelectorAll('input,textarea,select')) {
        if (input.closest('[data-dependency-groups][hidden]')) continue;
        if (input.dataset.choiceField) continue;
        if (input.dataset.arrayField || input.dataset.imageSizeField || input.dataset.cssIdField || input.dataset.wizardField) continue;
        if (input.dataset.unitValue) { values[input.dataset.unitValue] = { ...(values[input.dataset.unitValue] || {}), value: input.value }; continue; }
        if (input.dataset.unitName) { values[input.dataset.unitName] = { ...(values[input.dataset.unitName] || {}), unit: input.value }; continue; }
        if (input.dataset.widget === 'checkbox') values[input.name] = input.checked;
        else if (input.dataset.widget === 'datetime') values[input.name] = input.value ? String(Math.floor(new Date(input.value).getTime() / 1000)) : '';
        else if (input.dataset.widget === 'pageTree' && input.multiple) values[input.name] = [...input.selectedOptions].map((option) => option.value);
        else if (input.dataset.widget === 'fileTree') {
          try { values[input.name] = JSON.parse(input.value || '[]'); } catch { setPopoverSaving(false); status.textContent = 'Choose files from the library or enter valid JSON.'; status.classList.add('is-error'); submit.disabled = false; return; }
        }
        else if (input.dataset.widget === 'listWizard') values[input.name] = input.value.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
        else if (['rowWizard', 'tableWizard'].includes(input.dataset.widget)) values[input.name] = input.value.split(/\r?\n/).filter(Boolean).map((line) => line.split('\t'));
        else if (input.dataset.jsonStructuredValue || input.dataset.widget === 'imageSize' || (input.tagName === 'TEXTAREA' && input.value.trim().startsWith('['))) {
          try { values[input.name] = JSON.parse(input.value); } catch { setPopoverSaving(false); status.textContent = 'Enter valid JSON for this structured field.'; status.classList.add('is-error'); submit.disabled = false; return; }
        }
        else if (input.classList.contains('contao-live-edit-native-rte') && window.hugerte?.get(input.id)) values[input.name] = window.hugerte.get(input.id).getContent();
        else values[input.name] = input.value;
      }
      for (const name of new Set([...fieldPanel.querySelectorAll('[data-css-id-field]')].map((input) => input.dataset.cssIdField))) {
        values[name] = Object.fromEntries([...fieldPanel.querySelectorAll(`[data-css-id-field="${CSS.escape(name)}"]`)].map((input) => [input.dataset.cssIdKey, input.value]));
      }
      for (const name of new Set([...fieldPanel.querySelectorAll('[data-array-field]')].map((input) => input.dataset.arrayField))) {
        values[name] = [...fieldPanel.querySelectorAll(`[data-array-field="${CSS.escape(name)}"]`)].sort((a, b) => Number(a.dataset.arrayIndex) - Number(b.dataset.arrayIndex)).map((input) => input.value);
      }
      for (const name of new Set([...fieldPanel.querySelectorAll('[data-wizard-field]')].map((input) => input.dataset.wizardField))) {
        const rowMap = new Map();
        for (const input of fieldPanel.querySelectorAll(`[data-wizard-field="${CSS.escape(name)}"]`)) {
          const row = input.closest('.contao-live-edit-wizard-row');
          if (!rowMap.has(row)) rowMap.set(row, {});
          rowMap.get(row)[input.dataset.wizardColumn] = input.value;
        }
        const listWizard = fieldPanel.querySelector(`[data-wizard-field="${CSS.escape(name)}"]`)?.closest('.is-list-wizard');
        values[name] = [...rowMap.values()].map((row) => listWizard ? row.value : row);
      }
      for (const name of new Set([...fieldPanel.querySelectorAll('[data-image-size-field]')].map((input) => input.dataset.imageSizeField))) {
        values[name] = Object.fromEntries([...fieldPanel.querySelectorAll(`[data-image-size-field="${CSS.escape(name)}"]`)].map((input) => [input.dataset.imageSizeKey, input.value]));
      }
      values.invisible = visibilityButton.dataset.hidden === 'true';
      if (['youtube', 'vimeo'].includes(record.dataset.contaoLiveEditType)) {
        const mediaType = record.dataset.contaoLiveEditType;
        const mediaInput = fieldPanel.querySelector(`[name="${mediaType}"]`);
        const inputValue = mediaInput?.value.trim() || '';
        const match = mediaType === 'youtube' ? inputValue.match(/(?:youtu\.be\/|youtube(?:-nocookie)?\.com\/(?:watch\?v=|embed\/|shorts\/))([\w-]{11})/i) : inputValue.match(/vimeo\.com\/(?:video\/)?(\d{1,12})/i);
        values[mediaType] = match?.[1] || inputValue;
      }
      const choiceFields = new Set([...fieldPanel.querySelectorAll('[data-choice-field]')].map((input) => input.dataset.choiceField));
      for (const name of choiceFields) values[name] = [...fieldPanel.querySelectorAll(`[data-choice-field="${CSS.escape(name)}"]:checked`)].map((input) => input.value);
      try {
        await request('/contao-live-edit/save-element-fields', { id, fields: values });
        setPopoverSaving(false);
        closePopover(true); setMessage('Element saved'); window.setTimeout(() => window.location.reload(), 350);
      } catch (error) { setPopoverSaving(false); submit.disabled = false; status.textContent = error.message || 'Could not save element settings.'; status.classList.add('is-error'); }
    });
    const firstField = fieldPanel.querySelector('.contao-live-edit-source-editor') || fieldPanel.querySelector('.contao-live-edit-wizard-editor input, input:not([type="hidden"]),textarea,select');
    if (html) {
      const htmlToggle = fieldPanel.querySelector('.contao-live-edit-html-toggle');
      if (htmlToggle) {
        htmlToggle.click();
        return;
      }
      const selectedTemplate = record.dataset.contaoLiveEditTemplate || templateSelectedPath;
      await openTemplateEditor(selectedTemplate, record.dataset.contaoLiveEditType || '');
      return;
    }
    (firstField || popover.querySelector('[type="submit"]')).focus();
  };

  document.addEventListener('click', (event) => {
    const anchor = event.target.closest('a');
    if (!isActive() || replayingClick || event.target.closest('.contao-live-edit-inline-bar, .contao-live-edit-edit-popover, .contao-live-edit-action-bar, .contao-live-edit-move-handle, .contao-live-edit-settings-handle, .contao-live-edit-html-handle, .contao-live-edit-page-template-handle, [data-inline-ignore-links]')) return;
    const field = event.target.closest(fields) || inlineTextField(event.target);
    if (field && field !== activeField) {
      if (pendingClick) { window.clearTimeout(pendingClick.timer); pendingClick = null; }
      if (anchor) event.preventDefault();
      event.stopImmediatePropagation();
      begin(field, false);
      return;
    }
    if (!anchor) return;
    if (field === activeField) {
      event.preventDefault();
      return;
    }
    event.preventDefault();
    event.stopImmediatePropagation();
    if (pendingClick?.anchor === anchor && event.detail > 1) {
      window.clearTimeout(pendingClick.timer);
      pendingClick = null;
      return;
    }

    if (pendingClick) window.clearTimeout(pendingClick.timer);
    pendingClick = {
      anchor,
      timer: window.setTimeout(() => {
        const clickToReplay = pendingClick?.anchor;
        pendingClick = null;
        if (!clickToReplay?.isConnected) return;
        if (activeField && !finish(true)) return;
        replayingClick = true;
        clickToReplay.click();
        replayingClick = false;
      }, 280)
    };
  }, true);

  document.addEventListener('dblclick', (event) => {
    if (!isActive()) return;
    const directLink = event.target.closest('a');
    if (directLink?.closest('[data-inline-ignore-links]')) return;
    const link = directLink || elementAtPoint('a[href]', event.clientX, event.clientY);
    if (link?.closest('[data-contao-live-edit-type="hyperlink"]') && !link.closest('.contao-live-edit-inline-bar, .contao-live-edit-edit-popover')) {
      if (pendingClick) window.clearTimeout(pendingClick.timer);
      pendingClick = null;
      event.preventDefault();
      event.stopPropagation();
      openLinkEditor(link);
      return;
    }
    const caption = event.target.closest('figcaption');
    const captionField = caption && inlineTextField(caption);
    if (captionField && !caption.closest('.contao-live-edit-inline-bar, .contao-live-edit-edit-popover')) {
      event.preventDefault();
      event.stopPropagation();
      begin(captionField);
      return;
    }
    const image = event.target.closest('img') || elementAtPoint('img', event.clientX, event.clientY);
    if (image?.closest('[data-contao-live-edit-type="image"]') && !image.closest('.contao-live-edit-edit-popover')) {
      if (pendingClick) window.clearTimeout(pendingClick.timer);
      pendingClick = null;
      event.preventDefault();
      event.stopPropagation();
      openImageEditor(image);
      return;
    }
    const field = event.target.closest(fields)
      || inlineTextField(event.target)
      || [...document.querySelectorAll(fields)].find((candidate) => {
        const rect = candidate.getBoundingClientRect();
        return event.clientX >= rect.left && event.clientX <= rect.right && event.clientY >= rect.top && event.clientY <= rect.bottom;
      });
    if (!field || !isActive()) {
      const record = recordForTarget(event.target);
      if (record && !record.matches('[data-contao-live-edit-type="image"],[data-contao-live-edit-type="hyperlink"]')) {
        if (pendingClick) window.clearTimeout(pendingClick.timer);
        pendingClick = null;
        event.preventDefault(); event.stopPropagation(); openElementEditor(record);
      }
      return;
    }
    event.preventDefault();
    event.stopPropagation();
    begin(field);
  }, true);

  document.addEventListener('keydown', (event) => {
    const dialog = document.querySelector('[role="dialog"][aria-modal="true"]');
    if (dialog && event.key === 'Tab') {
      const focusable = [...dialog.querySelectorAll('a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])')]
        .filter((element) => element.getClientRects().length);
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (!first) {
        event.preventDefault();
        dialog.focus();
      } else if (event.shiftKey && (document.activeElement === first || !dialog.contains(document.activeElement))) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && (document.activeElement === last || !dialog.contains(document.activeElement))) {
        event.preventDefault();
        first.focus();
      }
    }
    if (templateModal?.isConnected && event.key === 'Escape') {
      event.preventDefault();
      closeTemplateModal();
      return;
    }
    if (popover && event.key === 'Escape') {
      event.preventDefault();
      closePopover(true);
      return;
    }
    if (isActive() && !activeField && ['Enter', 'F2'].includes(event.key)) {
      const field = event.target.closest(fields);
      if (field && !event.target.closest('.contao-live-edit-inline-bar, .contao-live-edit-edit-popover, .contao-live-edit-action-bar, .contao-live-edit-move-handle, .contao-live-edit-settings-handle')) {
        event.preventDefault();
        event.stopPropagation();
        begin(field);
        return;
      }
    }
    if (!activeField) return;
    if (event.key === 'Escape') {
      event.preventDefault();
      finish(true, true);
    } else if ((event.metaKey || event.ctrlKey) && event.key === 'Enter') {
      event.preventDefault();
      save();
    }
  });
  document.addEventListener('click', (event) => {
    if (popover && !popover.contains(event.target)) closePopover();
  });

  let activationTransitionHandler = null;
  let activationTransitionTimer = 0;
  const clearActivationTransition = (removeClass = true) => {
    if (activationTransitionHandler) bar.removeEventListener('transitionend', activationTransitionHandler);
    if (activationTransitionTimer) window.clearTimeout(activationTransitionTimer);
    activationTransitionHandler = null;
    activationTransitionTimer = 0;
    if (removeClass) bar.classList.remove('is-transitioning');
  };
  const animateActivation = (active) => {
    clearActivationTransition(false);
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduceMotion) {
      bar.classList.remove('is-transitioning');
      textMode = active;
      syncActivation();
      return;
    }

    void bar.offsetWidth;
    bar.classList.add('is-transitioning');
    textMode = active;
    syncActivation();
    if (isActive() !== active) {
      clearActivationTransition();
      return;
    }

    activationTransitionHandler = (event) => {
      if (event.target !== bar || event.propertyName !== 'max-width') return;
      clearActivationTransition();
    };
    bar.addEventListener('transitionend', activationTransitionHandler);
    activationTransitionTimer = window.setTimeout(clearActivationTransition, 600);
  };
  toggleButton.addEventListener('click', () => animateActivation(!isActive()));
  cancelButton.addEventListener('click', () => finish(true, true));
  saveButton.addEventListener('click', save);

  async function save() {
    if (!activeField) return;
    const field = activeField;
    const cleanedField = field.cloneNode(true);
    (renderedStateByField.get(field) || []).forEach(({ id, path, addedClasses, addedStyles }) => {
      const target = (id ? cleanedField.querySelector(`#${CSS.escape(id)}`) : null)
        || path.reduce((parent, index) => parent?.children[index] || null, cleanedField);
      if (!target) return;
      addedClasses.forEach((className) => target.classList.remove(className));
      addedStyles.forEach((property) => target.style.removeProperty(property));
    });
    cleanedField.querySelectorAll('.contao-live-edit-action-bar, .contao-live-edit-move-handle, .contao-live-edit-settings-handle').forEach((control) => control.remove());
    const contentRoot = cleanedField.matches('.rte') ? cleanedField : (cleanedField.querySelector('.rte') || cleanedField);
    const plainText = contentRoot.innerText.trim();
    const richTextField = ['text', 'teaser'].includes(field.dataset.inlineField);
    const value = richTextField ? contentRoot.innerHTML.trim() : plainText;
    if (!plainText && 'caption' !== field.dataset.inlineField) {
      setMessage('Text cannot be empty.', true);
      return;
    }

    saveButton.disabled = true;
    setMessage('Saving…');

    try {
      const response = await fetch(appUrl('/contao-live-edit/save-inline'), {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
        body: JSON.stringify({
          id: field.dataset.inlineRecord,
          recordType: field.dataset.inlineRecordType || 'content',
          field: field.dataset.inlineField,
          value,
          _token: token
        })
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Could not save this text.');
      const relatedFields = field.dataset.inlineRecordType === 'news'
        ? [...document.querySelectorAll(`[data-inline-record="${CSS.escape(field.dataset.inlineRecord)}"][data-inline-record-type="news"][data-inline-field="${CSS.escape(field.dataset.inlineField)}"]`)]
        : [field];
      if (['headline', 'subheadline'].includes(field.dataset.inlineField)) {
        relatedFields.forEach((target) => { target.textContent = result.value ?? plainText; });
      } else if ('caption' === field.dataset.inlineField) {
        if ('' === (result.value ?? plainText)) field.remove();
        else field.textContent = result.value ?? plainText;
      } else {
        for (const target of relatedFields) {
          const richText = target.matches('.rte') ? target : (target.querySelector('.rte') || target);
          mergeRenderedState(richText, result.value ?? value);
        }
      }
      originalMarkup = field.innerHTML;
      finish(false);
      setMessage('Saved');
      window.setTimeout(() => {
        if (!activeField) setMessage('');
      }, 1600);
    } catch (error) {
      if (activeField === field) field.contentEditable = 'true';
      saveButton.disabled = false;
      setMessage(error.message || 'Could not save this text.', true);
    }
  }
})();
